#include"snakef2.cpp"
main(){
  
  snake(1);
         
       } 
