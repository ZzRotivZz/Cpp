#include <stdio.h> 
#include <stdlib.h>
#include <conio.h>
#include <string.h>
int global=30;
void type(char arquivo[200],int opcao);

int main(int argc, char * argv[]){
       
       FILE * file;
       char c;
       char str[200];
       long tamanho=0;
       
       if( argc==1 || ( argv[1][0]=='/') || ( strcmp("--help",argv[1])==0)  )
          {
           printf(" Digite arquivoc [arquivo] [-e]\n");
           printf(" exibe strings para guardar programa c\n");
           printf(" Exibe o tamanho em bytes do arquivo \n");
           printf(" [-e] Exibe tabuladamente em hexadecimal \n");           
           printf(" [-d] Exibe tabuladamente a cada 16 bytes \n");           
           
           exit(0);
           }
           
       // DESCOBRE TAMANHO DO ARQUIVO           
       file=fopen(argv[1],"rb");
       while(1){
       fscanf(file, "%c", &c);
       if(feof(file))break;
       tamanho ++;  }       
       fclose(file);
       
       if(argc==2){
                   printf("char arquivo[]={\"");
                   type(argv[1],1);
                   printf("\"};");
                  printf("\n // Tamanho do arquivo %d Kb",tamanho);
                  printf("\n // for(int i=0;i<%d;i++)fputc(arquivo[i],file); ",tamanho);
                   }

       if(argc==3){
                   if(strcmp(argv[2],"-D")==0||strcmp(argv[2],"-d")==0)global=16;
                   type(argv[1],2);
                   }

                   
       }
void type(char arquivo[200],int opcao){

int counter, char_file; 
FILE *fp/*, *out */;

fp=fopen(arquivo, "rb");
char_file=fgetc(fp);
for (counter=0; char_file!=-1; counter++){
if (char_file!=-1){
if( opcao==1)printf ("\\x%x",char_file);
else {
     if(counter%global==0)printf("\n");
     printf("%.2x ",char_file);
     }
char_file=fgetc(fp); }
                                          } 
fclose(fp);
}

