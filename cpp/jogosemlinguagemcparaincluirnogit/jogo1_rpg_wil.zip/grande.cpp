#include"cls.cpp"
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define G gotoxy
void grande(int a){
switch(a){  
case 65 : 
G(60,5); puts(" _______");
G(60,6); puts("|       |");
G(60,7); puts("|_______|");
G(60,8); puts("|       |");
G(60,9); puts("|       |");
G(60,10);puts("|       |");
    
     break;
case 66 : 
G(60,5); puts(" _______");
G(60,6); puts("|       \\");
G(60,7); puts("|_______/");
G(60,8); puts("|       \\");
G(60,9); puts("|        |");
G(60,10);puts("|________/");
     break;
case 67 : 
G(60,5); puts(" _________");
G(60,6); puts("|            ");
G(60,7); puts("|            ");
G(60,8); puts("|            ");
G(60,9); puts("|            ");
G(60,10);puts("|_________");
     break;
case 68 : 
G(60,5); puts(" _______");
G(60,6); puts("|       \\");
G(60,7); puts("|        \\");
G(60,8); puts("|        |");
G(60,9); puts("|        /");
G(60,10);puts("|_______/");
     break;
case 69 : 
G(60,5); puts(" _______");
G(60,6); puts("|");
G(60,7); puts("|");
G(60,8); puts("|-----");
G(60,9); puts("|");
G(60,10);puts("|_______");
     break;
case 70 : 
G(60,5); puts(" ________");
G(60,6); puts("|");
G(60,7); puts("|________");
G(60,8); puts("|");
G(60,9); puts("|");
G(60,10);puts("|");
     break;
case 71 : 
G(60,5); puts(" ________");
G(60,6); puts("|");
G(60,7); puts("|"); 
G(60,8); puts("|    ____");
G(60,9); puts("|        |");
G(60,10);puts("|________|");
     break;
case 72 : 
G(60,5); puts(" ");
G(60,6); puts("|        |");
G(60,7); puts("|        |");
G(60,8); puts("|--------|");
G(60,9); puts("|        |");
G(60,10);puts("|        |");
     break;
case 73 : 
G(60,5); puts("    .    ");
G(60,6); puts("    |    ");
G(60,7); puts("    |    ");
G(60,8); puts("    |    ");
G(60,9); puts("    |    ");
G(60,10);puts("    |    ");
     break;
case 74 : 
G(60,5); puts("      .  ");
G(60,6); puts("      |  ");
G(60,7); puts("      |  ");
G(60,8); puts("      |  ");
G(60,9); puts(" |    |  ");
G(60,10);puts(" |____|  ");
     break;
case 75 : 
G(60,5); puts("|   / ");
G(60,6); puts("|  /");
G(60,7); puts("| /");
G(60,8); puts("| \\ ");
G(60,9); puts("|  \\");
G(60,10);puts("|   \\  ");
     break;
case 76 : 
G(60,5); puts("|        ");
G(60,6); puts("|         ");
G(60,7); puts("|         ");
G(60,8); puts("|         ");
G(60,9); puts("|         ");
G(60,10);puts("|______         ");
     break;
case 77 : 
G(60,5); puts("        ");
G(60,6); puts("|\\    /|  ");
G(60,7); puts("| \\  / |   ");
G(60,8); puts("|  \\/  |   ");
G(60,9); puts("|      |");
G(60,10);puts("|      | ");
     break;
case 78 : 
G(60,5); puts("        ");
G(60,6); puts("|\\    |  ");
G(60,7); puts("| \\   |   ");
G(60,8); puts("|  \\  |   ");
G(60,9); puts("|   \\ |");
G(60,10);puts("|    \\| ");
     break;
case 79 : 
G(60,5); puts(" _______");
G(60,6); puts("|       |");
G(60,7); puts("|       |");
G(60,8); puts("|       |");
G(60,9); puts("|       |");
G(60,10);puts("|_______|");
     break;
case 80 : 
G(60,5); puts(" _______");
G(60,6); puts("|       \\");
G(60,7); puts("|        |");
G(60,8); puts("|_______/");
G(60,9); puts("|       ");
G(60,10);puts("|       ");
     break;
case 81 : 
G(60,5); puts(" _______");
G(60,6); puts("|       |");
G(60,7); puts("|       |");
G(60,8); puts("|  __   |");
G(60,9); puts("|    \\__|");
G(60,10);puts("|_______|");
    break;
case 82 : 
G(60,5); puts(" ______");
G(60,6); puts("|      \\");
G(60,7); puts("|       |");
G(60,8); puts("|______/");
G(60,9); puts("|      \\");
G(60,10);puts("|       \\");
     break;
case 83 : 
G(60,5); puts(" _______");
G(60,6); puts("|       ");
G(60,7); puts("|       ");
G(60,8); puts(" -------");
G(60,9); puts("        |");
G(60,10);puts(" _______|");
     break;
case 84 : 
G(60,5); puts(" _______");
G(60,6); puts("    |   ");
G(60,7); puts("    |   ");
G(60,8); puts("    |   ");
G(60,9); puts("    |   ");
G(60,10);puts("    |   ");
     break;
case 85 : 
G(60,5); puts("        ");
G(60,6); puts("|       |");
G(60,7); puts("|       |");
G(60,8); puts("|       |");
G(60,9); puts("|       |");
G(60,10);puts("|_______|");
     break;
case 86 : 
G(60,5); puts("");
G(60,6); puts("\\        / ");
G(60,7); puts(" \\      /  ");
G(60,8); puts("  \\    /   ");
G(60,9); puts("   \\  /    ");
G(60,10);puts("    \\/     ");
     break;
case 87 : 
G(60,5); puts("|      |   ");
G(60,6); puts("|      |   ");
G(60,7); puts("|  /\\  |  ");
G(60,8); puts("| /  \\ |  ");
G(60,9); puts("|/    \\|   ");
G(60,10);puts("");
     break;
case 88 : 
G(60,5); puts("\\    / ");
G(60,6); puts(" \\  /  ");
G(60,7); puts("  \\/   ");
G(60,8); puts("  /\\   ");
G(60,9); puts(" /  \\  ");
G(60,10);puts("/    \\ ");
     break;
case 89 : 
G(60,5); puts("\\    / ");
G(60,6); puts(" \\  /  ");
G(60,7); puts("  \\/   ");
G(60,8); puts("  /     ");
G(60,9); puts(" /      ");
G(60,10);puts("/       ");
     break;
case 90 :
G(60,5); puts(" _______ ");
G(60,6); puts("       / ");
G(60,7); puts("     /     ");
G(60,8); puts("    /      ");
G(60,9); puts("   /       ");
G(60,10);puts(" /______        ");
 break;
default:
G(60,5); puts("         ");
G(60,6); puts("         ");
G(60,7); puts("         ");
G(60,8); puts("         ");
G(60,9); puts("         ");
G(60,10);puts("         ");
break;
      } // fim do switch(a)
     
     
     
     } // fim da fun��o grande
