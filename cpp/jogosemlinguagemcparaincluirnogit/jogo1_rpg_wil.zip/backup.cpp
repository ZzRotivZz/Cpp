#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
main(int argc,char *argv[]){
system("date /t > backup.txt");
FILE *file;
file=fopen("backup.txt","r");
char w[20];
fscanf(file,"%s",&w);
fscanf(file,"%s",&w);
fclose(file);
//printf("\n%s\n",w);
char nome[5];
nome[0]=w[0];
nome[1]=w[1];
nome[2]= 45;
nome[3]=w[3];
nome[4]=w[4];
char nome2[5];
for(int i=0;i<5;i++)nome2[i]=nome[i];
file=fopen("copia.bat","w");
fprintf(file,"@echo off\ncopy .\\jogo1.cpp .\\backup\\",nome2);
for(int i=0;i<5;i++)fprintf(file,"%c",nome[i]);
fprintf(file,".cpp\n"); 
fclose(file);      
system("copia");
       }
