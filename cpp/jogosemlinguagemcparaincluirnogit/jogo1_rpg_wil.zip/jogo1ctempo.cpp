#include<cls.cpp>
#include<conio.h>
#include"cai.cpp"
#include"topo.cpp"
#include"muda.cpp"
#include"comentario.cpp"
#include"acao.cpp"
#include"parede.cpp"
#include"paredep.cpp"
#include <time.h>
#define G gotoxy
#define PR printf
#define PU puts
#define D delay
#define W delay(1500);
#define T delay(50)
main(){
  float r; int n2,min,hora,min2, nt;
       r=clock(); n2=0; min=0; nt=0; min2=1; hora=0;
  //fim declara tempo tempo
  int pgpiramide=15,openpiramide=0,jogoteste=0,pgindio=35,morreu=0;
  int randomico,comentv,perfumaria,X,Y,caifora=0,y2=0,diagonal=0;
  int saiprova=0,aurelio=0,faltamrespr=10,certrespr=0,hermione=0,passteste=0;
  int aa=0,ab=0,ba=0,bb=0,bc=0,bd=0,ca=0,cb=0,cc=0,cd=0,da=0,db=0,dc=0,dd=0;
  int certo=0,usuario=0,demilton=500,dimas=1500,cabrini=3000,sua=20,hp=10000;
  int adv1=0,adv2=0,adv3=0,adv4=0,adv5=0,william=0,psand=0,ppedra=0;
  char pegasua; int quantia,pass=0,pedra=0,sanduiche=0,chave=0,direcional;
  int transf=0,mostra=0,corda=0,comentario=0,livro=0,andars=0,contlivro=0;;
  int get=0,b=0,c=1,barra=0,muro=1,e,t=1,tt=0,bolsa=0,maxpower=0;
  int tempo=90,aprendeu=0,sequencia=0,forma=1,jump=1,speed=2,subir=0;
  int rs=0,pulo=25, agil=10, conhecimento=1,pote=0;
  int x=25,y=20,fase=102,tela=0,antefase=0,password=0,senha=0,tpassword=0;
  int goku=0,espectro=0,agua=0,gasolina=0,alcool=0;
  int passaporte=0,vida=1,sangue=20,SANGUE=20;
  int joquemy=0,joquepc=0,teclajoque,joquemeu=0,jqpontpc=0,jqponteu=0,joquemrs=0;
  char bonec[15]; char tecla=3; char barrig='#'; char pc[20];
  char testep[10], resp[20];
  int antevida=vida,antesangue=SANGUE;
  randomico=rand()%10;
    while(1 && vida>0){
       caifora=0;  clrscr();
       //caso ele morra
if(morreu==1){
G(10,10);puts("   ||||||||||||");
G(10,11);puts("  ! ,,,    ,,, !");
G(10,12);puts(" (!( @ )!!( @ )!)");
G(10,13);puts("  !     ##     ! ");
G(10,14);  PR("  !    \xC8\xCD\xCD\xBC    !");
G(30,12); printf("%dx%c",vida,1);
delay(1000);
G(10,11);puts("  !            !");
G(10,12);puts(" (!(---)||(---)!)");
delay(1000);
for(int i=0;i<20;i++){
G(30,12); printf(" x%c ",1);delay(20);
G(30,12); printf("%dx%c ",vida,1);delay(20);
                       }
morreu=0; x=35;y=15;fase=3; forma=1;
vida--;        
if(vida==0){
G(30,12);printf("%dx%c",vida,1);delay(100);
G(10,12);puts(" (|(,,,)||(,,,)|)");
G(30,13);puts("morreu!!!!!!!!!!!!!");
delay(3000);
getche();
             }
else {
     G(30,13);puts("VC PERDEU 1 VIDA!!!!!!!!!!!!");
     delay(3000);
     getch();
     }
continue;}
       //fim caso ele morra
       X=Y=0;
       if(tecla==27)while(1){//menu  menu menu menu menu menu
       if(caifora>0)break;
       if(maxpower>1){ 
       G(1,1);printf("X=%d Y=%d TECLA=%d FASE=%d",X,Y,tecla,fase);}
       //relogio
       r=clock();
             if (n2!=nt){
             min2=1;
             min2=min%60;
             hora=min/60;
             hora=hora%24; 
             system("cls");
             printf("%d:%d:%d ",hora,min2,n2);
//             printf("r=%f  \n",r);
             }   
             if ( n2==59 && min2==1){min++;min2=0;}
             nt=n2;
             n2=((int)(r/1000))%60;   
       //fimrelogio
       G(19,8);puts("PERSON  ");
      G(19,10);puts("TECNICAS");
      G(19,12);puts("ITENS");
      G(19,14);puts("FECHAR     ");
      G(19,16);  PU("SAIR       ");
if(Y>-1){
G(18,Y+7);printf("%c%c%c%c%c%c%c%c%c%c",201,205,205,205,205,205,205,205,205,187);
G(18,Y+8);printf("%c",186);G(27,Y+8);PR("%c",186);
G(18,Y+9);printf("%c%c%c%c%c%c%c%c%c%c",200,205,205,205,205,205,205,205,205,188);}//fimse y>0
tecla=getche();
clrscr();
if(tecla==-32){tecla=getche();
switch(tecla){
              case 72:if(Y==0){Y=6;break;}Y=((Y-2)%10);break;
              case 80:Y=((Y+2)%10);break;}//fim swtich
}//se codigo extendido
if(Y==8 && tecla==13){caifora=2;tecla='a';continue;}
if(Y==6 && tecla==13){caifora=1;tecla='a';continue;}
if((tecla==13 || tecla==77) && Y==4 ){//ve item
             y2=0;
             do{
             for (int i=5;i<17;i++){G(30,i);puts("|");G(75,i);puts("|"); } 
             G(35,5);printf("SANDUICHE= %d",sanduiche);
             G(35,7);printf("CORDA    = %d",corda);
             G(35,9);printf("PEDRA    = %d",pedra);
             G(35,11);printf("CHAVE    = %d",chave);
             G(35,13);printf("(%d)LIVRO=  %d",contlivro,livro);
if(passaporte>0){G(55,6);puts("PASSAPORTE");}
G(34,y2+4);printf("%c%c%c%c%c%c%c%c%c%c%c",201,205,205,205,205,205,205,205,205,205,187);
G(34,y2+5);printf("%c",186);G(44,y2+5);PR("%c",186);
G(34,y2+6);printf("%c%c%c%c%c%c%c%c%c%c%c",200,205,205,205,205,205,205,205,205,205,188);             
G(34,15);tecla=getche();G(34,15);puts(" ");
G(34,y2+4);printf("           ");
G(34,y2+5);printf(" ");G(44,y2+5);PR(" ");
G(34,y2+6);printf("           ");
             if(tecla==-32){tecla=getche();switch(tecla){
                                         case 72:
                                              if(y2==0){y2=8;break;}
                                              y2=((y2-2)%10);break;
                                         case 80:y2=((y2+2)%10);break;
                                         }}
             }while(tecla!=75 && tecla!=27);
             }//fim ve item
if(Y==2 && tecla==13){
for (int i=5;i<17;i++){G(30,i);puts("|");G(75,i);puts("|"); } 
        if(pote>0)     {G(35,10); puts("POTE--------------------(P)");}
        if(aprendeu>3) {G(35,12); puts("HACKER-----------------(1&2)");}
        if(aprendeu>10){G(35,13); puts("INVISIBILIDADE---------(1&3)");} 
        if(aprendeu>15){G(35,14); puts("MAGIA-------------------(M)");}
        if(aprendeu>30){G(36,15); puts("GRAMPO------------------(G)");}
        if(aprendeu>50){G(35,16); puts("ARANHA-----------------(1&4)");}
        if(aprendeu>70){G(35,17); puts("MOSCA------------------(1&5)");}
        if(goku>0){G(35,12);      puts("TELETRANSPORTE-------<ENTER>");}
        //if(){G(35,7);           puts("MAGICA----(}
               
        }//fimse ve tecnicas
if(Y==0 && tecla==13){
gotoxy(1,10);pulo=jump*25;
printf("R$:%d\t\t|\nvida:%dx%c\t|\nsangue:%d/%d\t|\nconhecimento:%d\t|\npulo:%d\t\t|\nagilidade:%d\t|\n",
        rs,vida,1,sangue,SANGUE,conhecimento,pulo,agil);}
                        }//fim menu fimmenu fimenu fimenu fimenu fimenu
if(caifora==2)break; if(caifora==1)continue;
e=0; conhecimento=aprendeu;//if(aprendeu>4)livro=2;
if(speed==3)tempo=50;else if(speed==2)tempo=75;else
if(speed==1)tempo=100;else if(speed==0)tempo=120;else
if(speed==4)tempo=5; 
agil=speed*20+20;
if(conhecimento>12)jump=2;

//recebendo transforma��es e itens
if(antevida<vida){
G(10,10);puts("VC GANHOU 1 VIDA");W;getche();clrscr();antevida=vida;}
if(antesangue!=SANGUE){
G(10,10);puts("VC GANHOU SANGE+20!");W;getche();clrscr();antesangue=SANGUE;}
if(pote==1){gotoxy(10,10);puts("VC COMPROU ...");delay(1500);
gotoxy(10,11);puts("UM POTE !!!...???");delay(1500); pote=2; getche();clrscr();}
if(passteste==1){gotoxy(10,10);puts("VC GANHOU ...");delay(1500);
gotoxy(10,11);puts("Um passaporte de trem");delay(1500); passaporte=1; passteste=2;getche();clrscr();}
if(gasolina==1){G(10,10);puts("VC PEGOU GASOLINA!!!");gasolina=2;getche();clrscr();}
if(alcool==1){G(10,10);puts("VC PEGOU ALCOOL!!!!");alcool=2;getche();clrscr();}
if(ppedra<pedra){G(10,10);puts("VC PEGOU 1 PEDRA");W;ppedra=pedra;getche();clrscr();}
if(psand<sanduiche){G(10,10);PU("VC PEGOU 1 SANDUICHE");W;psand=sanduiche;getche();clrscr();}
if(adv1==2 && fase==9){G(10,10);puts("VC PEGOU RS 200,00");W;adv1=3;rs=rs+200;getche();clrscr();}
if(adv2==2 && fase==9){G(10,10);puts("Vc PEGOU RS 500,00");delay(1500);adv2=3;rs=rs+500;getche();clrscr();}
if(adv3==2 && fase==9){G(10,10);puts("VC PEGOU RS 1000,00");delay(1500); adv3=3;rs=rs+1000;getche();clrscr();}
if(bolsa==1){G(10,10);PU("VC PEGOU RS 100,00");delay(1500);bolsa=2;rs=rs+100;getche();clrscr();}
if(bolsa==3){G(10,10);PU("VC PEGOU RS 700,00");delay(1500);bolsa=4;rs=rs+700;getche();clrscr();}
if(goku==1){G(10,10);PU("VC GANHOU O PODER DO Goku");delay(1500);
G(10,11);PU("de se TRANSPORMAR Teletransporte <ENTER>");delay(1500);goku=2;getche();clrscr();}
if(espectro==1){gotoxy(10,10);puts("VC GANHOU O PODER DO RAZIEL");delay(1500);
gotoxy(10,11);puts("de ir ao mundo espectral <h>");delay(1500);espectro=2;getche();clrscr();}
if(aprendeu==4){gotoxy(10,10);puts("VC GANHOU O PODER DE SE");delay(1500);
G(10,11);PU("TRANSFORMAR EM HACKER <tecla>(2)");W; aprendeu++;contlivro=1;getche();clrscr();}
if(aprendeu==7){gotoxy(10,10);puts("VC GANHOU ...");delay(1500);
gotoxy(10,11);puts("O LIVRO DE INVISIBILIDADE !!!");delay(1500); 
gotoxy(10,12);puts("E UM CALENDARIO (NA KSA DO OSLVALDIR)");aprendeu++;getche();clrscr();}
if(aprendeu==9){gotoxy(10,10);puts("VC COMPROU ...");delay(1500);
gotoxy(10,11);puts("O OUTRO LIVRO DE INVISIBILIDADE !!!");W;aprendeu++;getche();clrscr();}
if(aprendeu==11){gotoxy(10,10);puts("VC GANHOU O PODER DE SER...");delay(1500);
gotoxy(10,11);puts("INVISIVEL !!! tecla<3>");D(1500);aprendeu++;contlivro=2;getche();clrscr();}
if(aprendeu==13){
G(10,10);puts("VC CONSEGUIU UM SALTO MAIOR!!! ");D(4000);aprendeu++;continue;getche();clrscr();}



//fim recebe

//transformar
if(tecla=='1')forma=1;
if(aprendeu>3)if(tecla=='2')forma=2;//hacker
if(aprendeu>10)if(tecla=='3')forma=8;//invisibilidade
if(aprendeu/10>=4 && pote==0)pote=2;
if(aprendeu/10>=5)if(tecla=='4')forma=6;//aranha
if(aprendeu>14 && passaporte==0)passaporte=1;
if(aprendeu/10>=7)if(tecla=='5')forma=7;//mosca
//if(aprendeu/10>=4)if(tecla=='6')barrig=80;else barrig='#';


//em cima da tela    
if(mostra==0){
gotoxy(1,1);pulo=jump*25;
printf("RS:%d\t\t|\nVIDAS:%dx%c\t|\nsangue:%d\t|\nconhecimento:%d\t|\n",
        rs,vida,1,sangue,conhecimento);}
if(mostra==1){
gotoxy(1,1);
puts("TECLAS ATIVAS:\t|\ns,d,f,q, ,\t|\nr, ,\t\t|");
               }
puts("________________|_____________|_______________________________________");

//TESTE DO MOSTRA  
if(mostra==0){
gotoxy(20,1);puts("tecnicas:");
if(aprendeu>30){G(20,2);puts("GRAMPO<G>");}
if(corda==1){G(20,3);puts("CORDA");}
if(pote>0){G(20,4);puts("POTE<P>");}
}
if(mostra==1){gotoxy(20,1);puts("ITENS:"); 
gotoxy(20,2);printf("SANDUICHE:%d",sanduiche);
gotoxy(20,3);printf("LIVRO:%d",livro);
if(pedra==0){
gotoxy(20,4);printf("CORDA:%d",corda);}
else{
gotoxy(20,4);printf("PEDRA:%d ",pedra);}}
//FIMTESTE DO MOSTRA

//COMENTARIO
gotoxy(35,1);puts("Comentario:");gotoxy(35,2);
comentario=coment(x,y,fase,conhecimento);
if(tecla>64 && tecla<91)comentario=6;
if(comentario==7 && aprendeu<30)comentario=0;
if(comentario==0)comentario=aprendeu;
switch(comentario){
    case 0: if(fase==102)break;
            puts("TENTE CONHECER MAIS CASAS");break;
    case 1: puts("VEJA SE ALGO MUDOU NO SEU CAMINHO");break;
    case 2: puts("VC PEGOU O LIVRO QUE O RONNEY ");
    G(35,4);puts("QUERIA");      break;
    case 3: puts("OPA!!! VC JA TEM 2 LIVROS?");break;
    case 5: puts("...");break;
    case 1001: puts("VC PRECISA CONSEGUIR ALGO");gotoxy(35,3);
            puts("PARA OBTER SUCESSO NESTE ");gotoxy(35,4);
            puts("LOCAL");break;
    case 1002: puts("VC NECESSITA DE UM SALTO");gotoxy(34,3); 
            puts("MAIOR P/ ALCANCAR A PORTA");break;
    case 1003: puts("\"ESPACO\"");break;
    case 1004: puts("CASA DE RONNEY (O MENINO GENIO) ");break;
    case 1005: puts("PRECIONE W,E ou R para saltar ");break;
    case 1006: puts("use s = <- e f = ->"); break;
    case 1007: puts("<ESPACO> ");break;
    case 1008: puts("SHOPPING PING DA MORTE "); break;
    case 1009: puts("TECLA <ESPACO> PARA MEXER NO PC"); break;
    case 1010: puts("VC PRECISA SE TRANSFORMAR");
            G(35,3);puts(" EM ARANHA PRA SUBIR LA");break;
    case 1011: puts("<ESPACO>");break;
    case 1012: if(forma!=8){puts("ENTRADA APENAS ");gotoxy(35,3);
                          puts("COM A CARTEIRINHA");}
    break;
    case 1013: puts("pagina flutuante");break;
    case 1014: puts("CUIDADO COM A FOGUEIRA!!!");break;
    case 1015: puts("UM PC!!!");break;
    case 1016: puts("APENAS UMA PESSOA COM PODERES ESPCIAIS");
    G(35,3);puts("SERIA CAPAZ DE ATRAVESSAR A PLATAFORMA");break;
    case 1017:printf("Aqui %c Hogwarts",130);break;
               }  
//FIMCOMENTARIO
//fim em cima da tela

if(agua==1){gotoxy(70,5);puts("Agua");}
if(gasolina==2){gotoxy(70,5);puts("Gasolina");}
if(alcool==2){gotoxy(70,5);puts("Alcool");}

//telas //telas //telas //telas imprimo telas imprimo fases
//teste de desenho de tela da fase correspondente
//fim teste desenho de tela
if(tela >0 && tecla==32)fase=tela;
switch(fase){
case 1:{   // tela 1
gotoxy(1,21);if(chave==1){puts(" _");puts("|8|"); }
gotoxy(1,23);
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
gotoxy(1,15);
puts(" ____ ");
puts("|    |");
puts("|   c|");
puts("|    |"); 
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww=====wwwwwwwwwwwwwwwwwwwwwwwwwww=");
gotoxy(42,13);puts("_____________");gotoxy(41,14);puts("/             \\");
gotoxy(41,15);puts("|     ______  |");gotoxy(41,17);puts("|    |     c| |");
gotoxy(41,16);puts("|    |      | |");gotoxy(41,18);puts("|    |      | |");
gotoxy(67,10);puts("  ######");       
gotoxy(67,11);puts("  ######");
gotoxy(67,12);puts("  ######");
gotoxy(67,13);puts("  ######");
gotoxy(67,14);puts(" =======");
gotoxy(16,6); puts("    ww");
gotoxy(16,7); puts("    ww");
gotoxy(16,8); puts("  _____");
gotoxy(16,9); puts(" |     |");
gotoxy(16,10);puts(" |    c|");
gotoxy(16,11);puts(" |     |");
gotoxy(16,12);puts(" wwwwwww");
gotoxy(16,13);puts(" wwwwwww");
gotoxy(16,14);puts(" wwwwwww");
if(conhecimento>15){G(22,6);puts("/___");G(22,7);puts("\\ ");}
if(conhecimento>30){for(int i=7;i<19;i++){G(24,i);puts("|");}} 
if(livro==1 && aprendeu==2){G(16,20);PU(" ___"); G(16,21);PU("/ H /");G(16,22);PU("LIVRO");}
if(x>16 && x<20 && y==20 && aprendeu<3 && tecla==32){livro++;aprendeu++;continue;mostra=1;}
if(antefase!=1)antefase=1;
break;


case 2://tela 2 
gotoxy(1,10);
if(antefase==4){x=17;y=16;antefase=2;}
if(antefase==3){x=6;y=20;antefase=2;}
if(antefase==1){x=3;y=16;antefase=2;}
puts("         ______________");
puts("        |              |");
puts("        |   SHOPPING   |");
puts("        |  PING   DA   |");
puts("        |    MORTE     |");
puts(" ____   |       _____  |");
puts("|    |  |      |     | |");
puts("|   c|  |      |    c| |");
puts("|    |  |      |     | |"); 
puts("================================     ==================    =============");
gotoxy(1,11);

gotoxy(41,6);puts("ww");gotoxy(41,7);puts("ww");gotoxy(41,8);puts("ww");
gotoxy(41,9);puts("ww");
gotoxy(41,10);puts("ww");gotoxy(41,11);puts("ww");gotoxy(41,12);puts("ww");
gotoxy(41,13);puts("ww");gotoxy(41,14);puts("ww");gotoxy(41,15);puts("ww");
gotoxy(41,16);puts("ww");gotoxy(41,17);puts("ww");gotoxy(41,18);puts("ww");
gotoxy(41,20);puts("ww");gotoxy(41,21);puts("ww");gotoxy(1,23);
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
gotoxy(44,16);puts("    __");
gotoxy(44,17);puts("   /__\\");gotoxy(44,18);puts("   [  ]");
gotoxy(5,20);puts("#####");
gotoxy(5,21);puts("#####");
gotoxy(5,22);puts("#####");
if(antefase!=2)antefase=2;
break;

case 3://tela 3
if(antefase==5){y=8;antefase=3;}
if(antefase==6){x=41;y=11; antefase=3;}
gotoxy(1,23);if(antefase==102){x=28;y=11;antefase=3;}
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
gotoxy(5,20);puts("#####");gotoxy(5,21);puts("#####");gotoxy(5,22);puts("#####");
gotoxy(5,19);puts("=====");gotoxy(1,11);puts("======");
gotoxy(8,15);puts("=====");gotoxy(69,18);puts("======");
    G(69,14);puts(" ___");
    G(69,15);puts("|   |");
    G(69,16);puts("|  c|");
    G(69,17);puts("|___|");
     

gotoxy(1,11);puts("==================");
gotoxy(19,14);puts("  ============================");
gotoxy(20,15);puts(" _   _   _               _   _   _ ");
gotoxy(20,16);puts("| |_| |_| |             | |_| |_| | ");
gotoxy(20,17);puts("|   __    |             |    __   |");
gotoxy(20,18);puts("|  |__|   |=============|   |__|  |");
gotoxy(20,19);puts("|         |  ________   |         |");
gotoxy(20,20);puts("|         | |        |  |         | ");
gotoxy(20,21);puts("|         | |        |  |         | ");
gotoxy(20,22);puts("|         | |        |  |         | ");
if(livro==0 && aprendeu==1){gotoxy(59,20);puts(" ___");gotoxy(59,21);puts("/ H /");
G(59,22);PU("LIVRO");}if(x>59 && x<62 && y==20 && aprendeu==1 && tecla==32){
livro=1;aprendeu++;continue;mostra=1;}
gotoxy(3,7); puts("  _____");
gotoxy(3,8); puts(" |     |");
gotoxy(3,9); puts(" |    c|");
gotoxy(3,10);puts(" |     |");
gotoxy(21, 9);puts("  ___________  ");
gotoxy(21,10);puts(" /_\\_________|     ######");
gotoxy(21,11);puts(" | | |     | |     ######");
gotoxy(21,12);puts(" | | |    c| |     ######");
gotoxy(21,13);puts(" | | |     | |     ######");
gotoxy(18,14);puts(" =============================");

if(antefase!=3)antefase=3;
break; // fim tela 3

case 102:   //casa do osvaldir
if(antefase!=102){x=48; y=16; antefase=102;}
if(forma!=1)if(forma==2);else forma=1;
gotoxy(46,15);puts(" ______ ");
gotoxy(46,16);puts("|      |");
gotoxy(46,17);puts("|     c|");
gotoxy(46,18);puts("|      |");
gotoxy(5,19);puts("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH");
gotoxy(6,15);  puts("       ");
gotoxy(6,16);printf("  %c  ",2);G(40,17);puts("|=|");
gotoxy(6,17);  puts("-|O|-");
gotoxy(6,18);  puts(" | | ");
gotoxy(56,16); puts("  |PASSWORD|");
gotoxy(56,17);puts("  ###########");
if(conhecimento>7){gotoxy(33,17);puts("|=|");}
if(x>31 && x<36 && y==16 && tecla==32 && conhecimento>7){
for(int i=0;i<10;i++){clrscr();G(1+i,1);PR("CALEND%cRIO",181);delay(300);}
char laco=0; while(laco!=27){
       clrscr();  G(10,1);PR("CALEND%cRIO (+ insira os dados corretos)OKKKK",181);G(1,2);
       int dia,mes,ano, mes1[12];int somames=0;
       printf("dia:");      scanf("%d",&dia);
       printf("\nmes:");    scanf("%d",&mes);
       printf("\nano:");    scanf("%d",&ano);
       int soma=ano/4;       int one=365*(ano-1);       printf("\n\n");
       mes1[0]=31;      mes1[1]=28;       mes1[2]=31;
       mes1[3]=30;      mes1[4]=31;       mes1[5]=30;
       mes1[6]=31;      mes1[7]=31;       mes1[8]=30;
       mes1[9]=31;      mes1[10]=30;      mes1[11]=31;
       for (int i=0; i<mes;i++){somames=mes1[i]+somames;}
       int total=(one+somames+soma+dia);      //printf("%i\n",total);
       if (ano%4==0 && mes<2)total--;       if(mes==2)total=total+31;
       int semana=total%7;  switch(semana){
       case 0: printf("quarta "); break;
       case 1: printf("quinta "); break;
       case 2: printf("sexta  "); break;
       case 3: printf("sabado "); break;
       case 4: printf("domingo"); break;
       case 5: printf("segunda"); break;
       case 6: printf("terca"  ); break;  }
       total=(one+somames+soma+1);     if (ano%4==0 && mes<3)total--;
if(mes==2)total=total+31;  semana=total%7;   //printf("%i\n",total); 
printf("\t%d/%d/%d\n",dia,mes,ano);   printf("D\tS\tT\tQ\tQ\tS\tS\n\n");
// printf("\nsomames=%d semana=%d total=%d one=%d",somames,semana,total,one);
       int dst;if (semana>3)dst=semana-4;  else dst=semana+3;
//       if (ano%4==0 && mes==2)mes1[mes-1]=29;
       for (int j=0;j<=mes1[mes-1];j++){
       if (j==0){for (int i=0; i<dst; i++)printf("\t");}     else{
       printf("%d\t",j);   dst=dst%7;  if (dst==6)printf("\n");  dst++;}   }
       puts("\n\n\tTECLA <ESC> PARA SAIR ");     laco=getche(); } 
       tecla='a';continue;     } //fimse ve calendario
if(x>37 && x<43 && tecla==32){
G(1,7);puts("USE AS TECLAS NUMERICAS PARA SE TRANSFORMAR\nGUARDE SEU PASSWORD:\n");
pass=qualpassword(conhecimento);if(pass!=100 && pass !=0)
printf("PASSWORD: %d",pass);}
if(x==53 && tecla==32){
gotoxy(40,8);puts("PASSWORD?");//gotoxy(55,12);//scanf("%d",&password);  
gotoxy(40,9);scanf("%s",&testep);tpassword=0;
for (int i=5;i>=0; i--){
    tt=(int)(testep[i]);    tpassword=(t*(tt-48))+tpassword;
    //gotoxy(1,10);printf("%d",password);getche();
     t=t*10;if(i==0)t=1;  }//  gotoxy(1,10);printf("%d",password);getche();
//printf("\t ==== %d %c",password, password);getche(); if(password)
senha=passwordfase(tpassword);gotoxy(20,20); 
if(senha>=1000){
if(senha==1000)rs=10000;
if(senha==1001)speed=4; 
if(senha==1002){speed=4;if(maxpower<2)maxpower=2;goku=2;espectro=2;diagonal=1;}
if(senha==1003)rs=rs+1;
if(senha==1004)goku=1;
if(senha==1005)if(maxpower<1)maxpower=1;
if(senha==1006){if(maxpower<2)maxpower=2;diagonal=2;}
if(senha==1007){
                if(rs<100000 && sua<100000)rs=rs+50000;speed=4;
                if(maxpower<2)maxpower=2;goku=2;espectro=2;
                if(aprendeu==0)aprendeu=99;
                diagonal=1;}
if(senha==1008)jogoteste=1;
}else
if(senha!=100 && senha !=0)aprendeu=senha;password=qualpassword(aprendeu);
//printf("CONHECIMENTO=%d, password: %d",aprendeu, password);
}//fim looping transformar char password em int password
}
if(tecla==32 && x<21){G(1,7);
if(livro<2){
switch(conhecimento){
case 2: puts(" Osvaldir: OHHH... vc ja tem um livro de hacker... ");
puts(" Qdo vc tiver 2 eu poderei te transformar!!!");break;
case 8: puts(" OSVALDIR: Eu preciso de apenas mais um livro");
puts(" De invisibilidade para te tranformar em invisivel");break;
case 10: aprendeu++;break;
case 11: break;
default: puts("OSVALDIR: Eu faco tranformaces diferentes em seres");
puts("humanos, basta me trazer livros e diferentes objetos");
puts(".... Os PASSWORDs se baseiam nessas tranformacoes");
break; // break default resposta osvaldir
} //fim switch conhecimento
}else{puts("NOVA TRANSFORMACAO...<ENTER>");aprendeu++;contlivro++;livro=0; continue;}

break;     // break ---> switch fase (tela)   

case 4: // shopping  tela 4
if(forma!=1)if(forma==2);else forma=1;
if(antefase==2){x=47;y=20;antefase=4;}
gotoxy(46,20);puts("|     |");gotoxy(46,21);puts("|    c|");
gotoxy(46,22);puts("|     |"); 
gotoxy(2,23);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,19);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,15);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,11);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,7);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWW");
G(28,8);puts("W");G(28,9);puts("W");G(28,10);puts("W");
G(20,22);puts("|      |");G(20,21);puts("|      |");G(20,20);puts("|      |");
G(20,18);puts("|      |");G(20,17);puts("|      |");G(20,16);puts("|      |");
G(20,14);puts("|      |");G(20,13);puts("|      |");G(20,12);puts("|      |");
G(20,10);puts("|      |");G(20,9);puts("|      |");G(20,8);puts("|      |");
if(x>20 && x<25 && tecla==32){
if(andars>2)y=y+4;else y=y-4;
andars=(andars+1)%6;}
for(int i=20; i>11; i=i-4){
G(1,i);puts("|   __|");puts("|  |__|");puts("|_____|");}
for(int i=20; i>11; i=i-4){
G(61,i);puts("|__   |");G(61,i+1);puts("|__|  |");G(61,i+2);puts("|_____|");}
if(x>57 && y==16 && tecla==32){//loja 22
G(30,7);puts("1. Velocidade: 75, R$ 1000");
G(30,8);puts("2. Velocidade: 100, R$ 10000");G(57,9); tecla=getche();G(57,9);PU(" ");
if(tecla=='1'){if(rs>999 && speed<3){rs=rs-1000;speed=3;continue;}else{ G(30,10); puts("VC NAO PODE COMPRA-LO");}}
if(tecla=='2'){if(rs>9999 && speed<4){rs=rs-10000;speed=4;continue;}else{ G(30,10); puts("VC NAO PODE COMPRA-LO");}}
}//FIM COMPRA DESSA LOJA
if(x>57 && y==20 && tecla==32){//loja  21
G(30,7);puts("1. pedra, R$ 5");
G(30,8);puts("2. sanduiche de presunto, R$ 5");   
G(57,9); tecla=getche();G(57,9);puts(" ");
if(tecla=='1'){if(rs>4 && pedra<100){rs=rs-5;pedra++;continue;}
else{ G(30,10); puts("VC NAO PODE COMPRA-LO");}}
if(tecla=='2'){if(rs>4 && sanduiche<100){rs=rs-5;sanduiche++;continue;}else{ G(30,10); puts("VC NAO PODE COMPRA-LO");}} 
}// FIM COMPRA DESSA LOJA
if(x<9 && y==20 && tecla==32){//loja  11
G(30,7);puts("1. livro 2 invisibilidade R$ 100");
G(30,8);puts("2. pote  R$ 1000");   
G(57,9); tecla=getche(); G(57,9);puts(" ");
if(tecla=='1'){if(rs>99 && livro==1 && conhecimento==8 ){rs=rs-100;aprendeu++;livro++;continue;}
else{ G(30,10); puts("VC NAO PODE COMPRA-LO");}}
if(tecla=='2'){if(rs>999 && pote==0){rs=rs-1000;pote=1;continue;}
else{ G(30,10); puts("VC NAO PODE COMPRA-LO");}} 
}// FIM COMPRA DESSA LOJA
if(x<9 && y==16 && tecla==32){//loja  12
G(30,7);puts("1. TELETRANSPORTE GOKU R$ 50000");
G(30,8);puts("2. PODER ESPECTRAL R$ 100000");   
G(57,9); tecla=getche(); G(57,9);PU(" ");
if(tecla=='1'){if(rs>49999 ){rs=rs-50000;goku=1;}
else{ G(30,10); puts("VC NAO PODE COMPRA-LO");}}
if(tecla=='2'){if(rs>9999){rs=rs-9999;espectro=1;}
else{ G(30,10); puts("VC NAO PODE COMPRA-LO");}} 
}// FIM COMPRA DESSA LOJA
if(x>57 && y==12 && tecla==32){
G(30,7);puts("1. vida RS 500");
G(30,8);puts("2. + sangue RS 750");
G(57,9);tecla=getche(); G(57,9);puts(" ");
if(tecla=='1'){if(rs>499 && vida<10){rs=rs-500;vida++;continue;}
else{ G(30,10);puts("VC NAO PODE COMPRA-LO");}}        
if(tecla=='2'){if(rs>749 && SANGUE<100){rs=rs-750;SANGUE+=20;sangue=SANGUE;continue;}
else{ G(30,10);puts("VC NAO PODE COMPRA-LO");}}     
} // FIM COMPRA DESSA LOJA 23  
if(antefase!=4)antefase=4;
break;

case 5: // sabesp tela 5
if(antefase==3){x=6;y=20;antefase=5;}
gotoxy(4,19);puts(" _____");
gotoxy(4,20);puts("|     |");
gotoxy(4,21);puts("|    c|");
gotoxy(4,22);puts("|     |");
gotoxy(1,23);
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
gotoxy(10,14);puts("ww====ww");
gotoxy(27,18);printf("  %c  ",2);
gotoxy(27,19);  puts("  PP ");
gotoxy(27,20);  puts(" /  \\");
G(53,18);puts("     _________");
G(53,19);puts("  //|         |");
G(53,20);puts(" // | SABESP  |");
G(53,21);puts("//  |         |");
G(53,22);puts("    |         |");
G(41,15);puts("    ________  ");
G(41,16);puts("   |        |");
G(41,17);puts("   |      c |");
G(41,18);puts("   |        |");
G(41,19);puts("=============");
if(x>49 && x<53 && tecla=='p' && pote>0){pote=2; 
for(int i=39;i<45;i++){G(i-1,10);puts("           ");
G(i,10);puts("O POTE ESTA COM AGUA");delay(100);}agua=1;gasolina=0;alcool=0;   } 
if(forma==8 || x<25  || y<10){G(32,10);puts("TTT");}
else{for (int i=10;i<23;i++){G(27,19);puts("-");G(32,i);  puts("TTT");}}
if(bolsa==2){gotoxy(42,21);puts("\\_/");G(42,22);printf("(%c)",36);
if(x==42 && tecla==32){bolsa=3;continue;}}
if(antefase!=5)antefase=5;
break;

case 6: // hotel por fora
     if(antefase==5){x=5;y=20;}
     if(antefase==110){x=22;y=20;}
     if(antefase==3){x=6;y=20;}
        
gotoxy(1,23);
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
gotoxy(4,19);puts("######");
gotoxy(4,20);puts("######");
gotoxy(4,21);puts("######");
gotoxy(4,22);puts("######");
gotoxy(18,9); puts("|------------|");
gotoxy(18,10);puts("|  __   ___  |");
G(18,11);   printf("| |__| |_%c_| |",148);
G(18,12);   printf("|  __   __   |");
gotoxy(18,13);puts("| |__| |__|  |");
gotoxy(18,14);puts("| __  ___  _ |");
G(18,15);   printf("||__||_%c_||_||",148);
gotoxy(18,16);puts("|H----------B|");
gotoxy(18,17);puts("|!HOTEL HUB !|");
gotoxy(18,18);puts("|H----U-----B|");
gotoxy(18,19);puts("| _______    |");
gotoxy(18,20);puts("||       |   |");
gotoxy(18,21);puts("||      c|   |");
gotoxy(18,22);puts("||       |   |");
G(47,14); PU("=================");
G(47,15); PU("|ALCOOL&GASOLINA|");
G(47,16); PU("|_______________|");
G(46,17);PU("===================");
G(48,18);puts("||   __      ||");
G(48,19);puts("||  |[]|     ||");
G(48,20);puts("||   ||      ||");
G(48,21);puts("|| //||\\\\    ||");
G(48,22);puts("||  |  |     ||");
if(conhecimento == 5){
G(42,22);printf("%c#==",1);
if(x==35 || x==40 || x==45){
if(sanduiche==0){G(40,12);puts("CABRINI:");
G(40,15);puts("AGS AGS, PRECISO COMER ALGO!!!");
G(40,14);puts(" SOCORROOOOOOOOOOOO HELP ME AJUDE!");
G(40,13);puts(" Estou morren...do de fome...ags ags");
delay(500);}
else{G(40,7);puts("CABRINI:");
G(40,8);puts("vc serah recompensado... muito obrigado");
G(40,9);puts("va ateh minha casa que");
G(40,10);puts("Te darei uma reconpensa... ");
G(40,11);puts("thank you so much!!!!");
sanduiche--;
aprendeu++;
delay(6500);}// fim else posicao tal
}// fimse posicao tal
}//fim se conhecimento 5
if(x>48 && x<52 && tecla=='p'){agua=0;gasolina=0;alcool=1;pote=3;tecla='a';continue;}
if(x>53 && x<57 && tecla=='p'){agua=0;gasolina=1;alcool=0;pote=4;tecla='a';continue;}
if(antefase!=6)antefase=6;
break; //break; tela 6

case 7:// indo para hogwarts trem plataforma 9 e meio tela 7
if(antefase==10){
G(2,15);puts(" ! !");G(2,16);  PR(" ! !_%c____",190);//190
G(2,17);puts(" | _____ |");G(2,18);puts(" ||=====||");
G(2,19);puts(" ||     ||");G(2,20);puts(" ||     ||");
G(2,21);puts("!=========!");G(2,22);puts("  ######  ");delay(3000);}
G(32,19);puts(" ________ ");
G(32,20);puts("|        |");
G(32,21);puts("|        |");
G(32,22);puts("|        |");
gotoxy(1,23);
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
for (int i=22;i>5;i--){
G(60+(i%4),i);puts(", ,");}
G(23+(30),6);printf("   %c",1);
G(23+(30),7);  puts("===##==<");
G(23+(30),8);  puts("   //");
G(12,12);puts(" ___");
G(12,13);puts("! 9 !");
G(12,14);  PR("! %c !",171);
G(12,15);puts("!   !");G(12,16);puts("!   !");G(12,17);puts("!   !");
G(12,18);puts("!   !");G(12,19);puts("!   !");G(12,20);puts("!   !");
G(12,21);puts("!   !");G(12,22);puts("!   !");
G(2,8);printf("       %c",14);
G(2,9);printf("  %c ",14); 
G(2,11);puts(" ~~ ");
G(2,12);puts(" (( ");
G(2,13);puts("  ))");    
G(2,14);puts(" ((");
G(2,15);puts(" ! !");
G(2,16);  PR(" ! !_%c____",190);//190
G(2,17);puts(" | _____ |");
G(2,18);puts(" ||=====||");
G(2,19);puts(" ||     ||");
G(2,20);puts(" ||     ||");
G(2,21);puts("!=========!");
G(2,22);puts("  ######  ");
G(69,21);puts("[=]");
if(x>68 && y==20 && tecla==32){//if tecla espaco la aristoteles
        for(int i=1; i<14 ; i++){  clrscr(); //primeiro
       G(5+i,3);puts(" Se um dia vc se sentir iludido por um objetivo... ");
       delay(100); }
       for(int i=1; i<14 ; i++){ clrscr();
       G(18,3);puts(" Se um dia vc se sentir iludido por um objetivo... "); 
G(4+i,4);puts(" lembre-se que o importante na vida nao sao os objetivos "); 
G(4+i,5);puts("que propomos, mas o caminho que seguimos para conquista-los");
delay(200);}
       delay(1000);
       
for(int i=1; i<14 ; i++){ clrscr(); //segundo
G(18,3);puts(" Se um dia vc se sentir iludido por um objetivo... "); 
G(17,4);puts(" lembre-se que o importante na vida nao sao os objetivos "); 
G(17,5);puts("que propomos, mas o caminho que seguimos para conquista-los");
       G(5+i,7);puts(" Se um dia vc se sentir uma gota no meio do oceano... ");
       delay(100); }
       for(int i=1; i<14 ; i++){clrscr();
G(18,3);puts(" Se um dia vc se sentir iludido por um objetivo... "); 
G(17,4);puts(" lembre-se que o importante na vida nao sao os objetivos "); 
G(17,5);puts("que propomos, mas o caminho que seguimos para conquista-los");
G(18,7);puts(" Se um dia vc se sentir uma gota no meio do oceano... ");
G(4+i,8);puts(" lembre-se que sem essa gota o oceano seria menor.  "); 
delay(100);}
       delay(1000);

for(int i=1; i<14 ; i++){ clrscr();//terceiro
G(18,3);puts(" Se um dia vc se sentir iludido por um objetivo... "); 
G(17,4);puts(" lembre-se que o importante na vida nao sao os objetivos "); 
G(17,5);puts("que propomos, mas o caminho que seguimos para conquista-los");
G(18,7);puts(" Se um dia vc se sentir uma gota no meio do oceano... ");
G(17,8);puts(" lembre-se que sem essa gota o oceano seria menor.  ");
       G(5+i,10);puts("Se um dia vc se sentir dentro de um buraco... ");
       delay(100); }
              
       for(int i=1; i<14 ; i++){   clrscr();
G(18,3);puts(" Se um dia vc se sentir iludido por um objetivo... "); 
G(17,4);puts(" lembre-se que o importante na vida nao sao os objetivos "); 
G(17,5);puts("que propomos, mas o caminho que seguimos para conquista-los");
G(18,7);puts(" Se um dia vc se sentir uma gota no meio do oceano... ");
G(17,8);puts(" lembre-se que sem essa gota o oceano seria menor.  "); 
G(18,10);puts("Se um dia vc se sentir dentro de um buraco...");
G(4+i,11);puts("lembre-se que por mais fundo que ele seje,");
G(4+i,12);puts("ainda nao ha terra por cima dele.");
delay(100);}
       delay(1000);

for(int i=1; i<14 ; i++){ clrscr();//quarto
G(18,3);puts(" Se um dia vc se sentir iludido por um objetivo... "); 
G(17,4);puts(" lembre-se que o importante na vida nao sao os objetivos "); 
G(17,5);puts("que propomos, mas o caminho que seguimos para conquista-los");
G(18,7);puts(" Se um dia vc se sentir uma gota no meio do oceano... ");
G(17,8);puts(" lembre-se que sem essa gota o oceano seria menor.  ");
G(18,10);puts("Se um dia vc se sentir dentro de um buraco... ");
G(17,11);puts("lembre-se que por mais fundo que ele seje,");
G(17,12);puts("ainda nao ha terra por cima dele.");
G(5+i,14);puts("C 1 dia vc sentir vontade de desistir...");
delay(100); }
       for(int i=1; i<14 ; i++){   clrscr();
G(18,3);puts(" Se um dia vc se sentir iludido por um objetivo... "); 
G(17,4);puts(" lembre-se que o importante na vida nao sao os objetivos "); 
G(17,5);puts("que propomos, mas o caminho que seguimos para conquista-los");
G(18,7);puts(" Se um dia vc se sentir uma gota no meio do oceano... ");
G(17,8);puts(" lembre-se que sem essa gota o oceano seria menor.  "); 
G(18,10);puts("Se um dia vc se sentir dentro de um buraco...");
G(17,11);puts("lembre-se que por mais fundo que ele seje,");
G(17,12);puts("ainda nao ha terra por cima dele.");
G(18,14);puts("C 1 dia vc sentir vontade de desistir...");
G(4+i,15);puts("lembre-se que na vida todos tropecam e caem");
G(4+i,16);puts("Mas apenas os fracos ficam estirados ao longo do caminho");
delay(100);}
       delay(1500);

for(int i=1; i<14 ; i++){ clrscr();//quinto
G(18,3);puts(" Se um dia vc se sentir iludido por um objetivo... "); 
G(17,4);puts(" lembre-se que o importante na vida nao sao os objetivos "); 
G(17,5);puts("que propomos, mas o caminho que seguimos para conquista-los");
G(18,7);puts(" Se um dia vc se sentir uma gota no meio do oceano... ");
G(17,8);puts(" lembre-se que sem essa gota o oceano seria menor.  ");
G(18,10);puts("Se um dia vc se sentir dentro de um buraco... ");
G(17,11);puts("lembre-se que por mais fundo que ele seje,");
G(17,12);puts("ainda nao ha terra por cima dele.");
G(18,14);puts("C 1 dia vc sentir vontade de desistir...");
G(17,15);puts("lembre-se que na vida todos tropecam e caem");
G(17,16);puts("Mas apenas os fracos ficam estirados ao longo do caminho");
G(5+i,18);puts("C 1 dia vc c sentir um otario pq ama alguem...");
delay(100); }
       for(int i=1; i<14 ; i++){   clrscr();
G(18,3);puts(" Se um dia vc se sentir iludido por um objetivo... "); 
G(17,4);puts(" lembre-se que o importante na vida nao sao os objetivos "); 
G(17,5);puts("que propomos, mas o caminho que seguimos para conquista-los");
G(18,7);puts(" Se um dia vc se sentir uma gota no meio do oceano... ");
G(17,8);puts(" lembre-se que sem essa gota o oceano seria menor.  "); 
G(18,10);puts("Se um dia vc se sentir dentro de um buraco...");
G(17,11);puts("lembre-se que por mais fundo que ele seje,");
G(17,12);puts("ainda nao ha terra por cima dele.");
G(18,14);puts("C 1 dia vc sentir vontade de desistir...");
G(17,15);puts("lembre-se que na vida todos tropecam e caem");
G(17,16);puts("Mas apenas os fracos ficam estirados ao longo do caminho");
G(18,18);puts("C 1 dia vc c sentir um otario pq ama alguem...");
G(4+i,19);puts("lembre-se que a  menor particula de um sentimento ");
G(5+i,20);puts(" passa por cima da maior porcao de razao.");
delay(100);}
delay(1500);
       for (int i=1;i<14;i++){
G(1,22);puts("                                                  ");
G(20,22);puts("                                                    ");
G(5+i,22);puts(" Se um dia vc sentir que nao entende a vida...");delay(100);}
for (int i=1;i<14;i++){
G(1,23);puts("                                                  ");
G(20,23);puts("                                                    ");
G(5+i,23);puts(" lembre-se que a morte eh certa, a vida nao.");delay(100);}
getche(); x--; tecla='a';continue;

        }//fim se tecla espaco la aristoteles

if(antefase!=7)antefase=7;     
break;// break indo para hogwarts

case 8:// la em cima da corda tela 8
if(antefase==12){tecla='a';}
gotoxy(1,23);
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
G(23,18);puts(" ______ ");
G(23,19);puts("|######|");
G(23,20);puts("|######|");
G(23,21);puts("|######|");
G(23,22);puts("|######|");
G(55,19); puts("  \\ ! /");
G(55,20);puts(" \\\\ | //");
G(55,21);puts("\\\\ | | //");
G(53,22);puts("=============");
for(int i=14;i<23;i++){G(52,i);puts("w");}
G(6,14);puts("  _____ ");
G(6,15);puts(" |     |");
G(6,16);puts(" |    c|");
G(6,17);puts(" |     |");
G(6,18);puts("=============");
G(20,14);puts("/##\\");
if(tecla==32 && forma==2 && pgindio<43)pgindio++;
//if(tecla==-32)tecla=getche();
if((direcional==83 || tecla==8) && forma==2 && pgindio>23)pgindio--;
G(17,16);puts("=============");
G(53,11);printf(" %c",2);
G(53,12);printf("/I\\");
G(53,13);printf("/ \\");
G(32,14);puts("=======================");
G(pgindio,12);puts("|=|");
if(x>49 && y>18){morreu=1;continue;}
antefase=8;
break;//break la em cima da cordas

case 9:// portinha do jump++ tela 9
if(antefase==300){x=50;y=11;}
if(antefase==12){y=10;} 
G(1,23);PU("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
G(69,14);puts(" ___");G(69,18);puts("======");
G(69,15);puts("|   |");
G(69,16);puts("|  c|");
G(69,17);puts("|___|");G(69,18);puts("======");
G(1,14);PU("===========================================================");
G(35,18);PU("=====");
gotoxy(43,7); puts("|--------------|");
gotoxy(43,8); puts("|(((())()(())))|");
gotoxy(43,9); puts("|  LAS VEGAS   |");
gotoxy(43,10);puts("| ������������ |");
gotoxy(43,11);puts("|    !$$$$$!   |");
gotoxy(43,12);puts("|    !$$$$$!   |");
gotoxy(43,13);puts("|    !$$$$$!   |");
G(2,8);   PR(" _, ,_____",190);//190
G(2,9); puts(" | _____ |");
G(2,10);puts(" ||=====||");
G(2,11);puts(" ||     ||  ");
G(2,12);puts(" ||     || |=|");
G(2,13);puts("!=========!");
if(x>10 && x<16 && y==11 && tecla==32){
G(15,7);puts("EMBARQUE APENAS");
G(15,8);puts("COM O PASSAPORTE");  }
if(x<8 && x>4 && y==10 && tecla==32 && passaporte>0){
       tela=12;fase=12;y=19;delay(200);continue;
                                                     }
//G(47,19);puts(" ___"); G(40,19);puts(" ___"); G(30,19);puts(" ___");
//G(47,20);puts("|   |");G(40,20);puts("|   |");G(30,20);puts("|   |");
G(47,21);if(adv1==0) puts(" ___"); else puts("(   )");
G(40,21);if(adv2==0) puts(" ___"); else puts("(   )");
G(30,21);if(adv3==0) puts(" ___"); else puts("(   )");
G(47,22);puts("|_8_|");G(40,22);puts("|_8_|");G(30,22);puts("|_8_|");
gotoxy(15,20);printf(" %c",1);
gotoxy(15,21);  puts("/W\\");
gotoxy(15,22);  puts("/ \\");
if(tecla==32 && x>11 && x<19 && y==20){//fala
   if(adv1==0){
            gotoxy(20,12); puts(" charada 1:");
            gotoxy(20,13); puts(" O que eh o que eh...");
            gotoxy(20,14); puts(" se disser meu nome nao existirei mais?");
            G(20,15); puts(" RESPOSTA:"); G(31,15);
            scanf("%s",&resp);
if((resp[0]=='s' || resp[0]=='S' )&& resp[1]=='i' && resp[2]=='l' && 
(resp[3]=='�' || resp[3]=='e')&& resp[4]=='n' && resp[5]=='c' && resp[6]=='i' 
&& resp[7]=='o'){adv1=1;continue;}} //fim se adv1==0
   if(adv2==0 && adv1==3){
    G(20,12);      puts(" charada 2:");
    gotoxy(20,13); puts(" O que eh o que eh...");
    gotoxy(20,14); puts(" Eh maior que Deus, os pobres nao tem");
    gotoxy(20,15); puts(" E os ricos nao precisam?");
    G(20,16); puts(" Resposta: "); G(31,16);
    scanf("%s",&resp);
    if((resp[0]=='N' || resp[0]=='n' )&& (resp[1]=='a' || resp[1]=='A') && 
    (resp[2]=='d' || resp[2]=='D') && (resp[3]=='A' || resp[3]=='a')){adv2=1;
    continue;}}       //fim se adv2==0
if(adv3==0 && adv2==3){
            gotoxy(20,12); puts(" charada 3:");
            gotoxy(20,13); puts(" 4 romanos e 1 ingles amavam uma mulher...");
            gotoxy(20,14); puts(" Ql era o nome dela?");
            G(20,15);puts("resposta:");G(31,15);
            scanf("%s",&resp);
        if((resp[0]=='I' || resp[0]=='I' )&& resp[1]=='v' && resp[2]=='o' && 
(resp[3]=='n' || resp[3]=='n')&& resp[4]=='e'){adv3=1;continue;}}// fim se adv3==0
                  }//fim fala
if(adv1==1 && tecla==32 && x==48){adv1=2; continue;}
if(adv2==1 && tecla==32 && x==41){adv2=2; continue;}
if(adv3==1 && tecla==32 && x==31){adv3=2; continue;}
if(speed<4){
gotoxy(2,20);PR(" _ %c",64);
G(2,21);   puts("/--G_= ");
G(1,22);  puts("O    O  ");
if(x<10 && tecla==32){
if(gasolina==0){
G(4,15); puts(" Guilherme:");delay(800);
G(4,16); puts(" Acabou a gasolina da minha moto :(");delay(1000);}
if(gasolina>0){
G(4,15); puts(" Guilherme:");delay(800);
G(4,16); puts(" Muito Obrigado pela gasolina");delay(200);
G(4,17);puts("###VC GANHOU O PODER DE VELOCIDADE!!!"); gasolina=0; speed=4;}
}//fimse fala c guilherme
}// fim se speed <4



if(antefase!=9)antefase=9;     
break;// break portinha do jump++ tela 9

case 10: //tela 10 em Hogwarts definitivamente dentro de hogwarts
if(antefase==7){
G(2,15);puts(" ! !");G(2,16);  PR(" ! !_%c____",190);//190
G(2,17);puts(" | _____ |");G(2,18);puts(" ||=====||");
G(2,19);puts(" ||     ||");G(2,20);puts(" ||     ||");
G(2,21);puts("!=========!");G(2,22);puts("  ######  ");delay(3000);}
gotoxy(1,23);
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
G(2,8);printf("       %c",14);
G(2,9);printf("  %c ",14); 
G(2,11);puts(" ~~ ");
G(2,12);puts(" (( ");
G(2,13);puts("  ))");    
G(2,14);puts(" ((");
G(2,15);puts(" ! !");
G(2,16);  PR(" ! !_%c____",190);//190
G(2,17);puts(" | _____ |");
G(2,18);puts(" ||=====||");
G(2,19);puts(" ||     ||");
G(2,20);puts(" ||     ||");
G(2,21);puts("!=========!");
G(2,22);puts("  ######  ");
if(bolsa==0){gotoxy(42,21);puts("\\_/");G(42,22);printf("(%c)",36);
if(x==42 && y==20 && tecla==32){bolsa=1;continue;}}
G(24,13);puts("  __________________");
G(24,14);puts(" /CONCURSO DE MAGIA \\");
G(24,15);puts("|,,,,,,,______,,,,,,,|");
G(24,16);puts("|,,,,,,|      |,,,,,,|");
G(24,17);puts("|,,,,,,|     c|,,,,,,|");
G(24,18);puts("|,,,,,,|      |,,,,,,|");
G(14,19);puts("====================================");
for(int i=6;i<23;i++){
        gotoxy(58,i);puts("lPl");}
if(antefase!=10)antefase=10;
break;
case 300: // las vegas jogos de azar
if(forma!=1)if(forma==2);else forma=1;
if(antefase==9){x=48;y=20;antefase=4;}
gotoxy(46,20);puts("!$$$$$!");gotoxy(46,21);puts("!$$$$$!");
gotoxy(46,22);puts("!$$$$$!"); 
gotoxy(2,23);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,19);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,15);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,11);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,7);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWW");
G(28,8);puts("W");G(28,9);puts("W");G(28,10);puts("W");
G(20,22);puts("|      |");G(20,21);puts("|      |");G(20,20);puts("|      |");
G(20,18);puts("|      |");G(20,17);puts("|      |");G(20,16);puts("|      |");
G(20,14);puts("|      |");G(20,13);puts("|      |");G(20,12);puts("|      |");
G(20,10);puts("|      |");G(20,9);puts("|      |");G(20,8);puts("|      |");
G(5,12);puts("|   |");
G(5,13);puts("|###|");
G(5,14);puts("|   |");
if(x>20 && x<25 && tecla==32){
if(andars>2)y=y+4;else y=y-4;
andars=(andars+1)%6;}
if(x<7 && y==12 && rs>0 && tecla==32){
clrscr();
G(2,2);puts("DESEJA JOGAR JOQUEMPO?(s/n) ");
tecla=getche(); G(1,3);puts(" ");
if(tecla!='s'){tecla='a';continue;}
G(2,3);puts("APOSTAS DE:");
scanf("%d",&joquemrs);
if(joquemrs>rs && rs<100000000 && rs<100001){tecla='a';continue;}
G(1,4);puts(" MELHOR DE 12");delay(1500);

       //JOQUEMPOCOMECO
joquemy=0,joquepc=0,teclajoque,joquemeu=0,jqpontpc=0,jqponteu=0;
//for(int i=0;i<20;i++)joquepc=rand()%60;
while(1 && jqpontpc<12 && jqponteu<12){
clrscr();
joquepc=rand()%3+1;
G(50,12);puts("| tesoura | ");
G(50,14);puts("|  pedra  | ");
G(50,16);puts("|  papel  | ");     
G(50,18);puts("|   sai   | ");
G(2,2);
//printf("joquemy=%d,teclajoque=%d,joquemeu=%d,joquepc=%d",joquemy,teclajoque,joquemeu,joquepc);
//if(teclajoque==80){joquemy=(joquemy+2)%8;} if(teclajoque==72){joquemy=(joquemy+6)%8;}
if(joquemy==-2)joquemy=6;
if(joquemeu>0){
if(joquepc==1){G(20,10);puts("  _  _");
               G(20,11);puts(" (_)(_)");
               G(20,12);puts("  //\\\\");
               G(20,13);puts(" //  \\\\"); }               
if(joquepc==2){G(20,10);puts("  ....");
               G(20,11);puts(" ......");
               G(20,12);puts("........");
               G(20,13);puts(" ......"); 
               G(20,14);puts("  ....");               }
if(joquepc==3){G(20,10);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");
               G(20,11);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");
               G(20,12);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");
               G(20,13);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");
               G(20,14);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");  }
if(joquemeu==1){
                G(20,17);puts(" \\\\  //");
                G(20,18);puts("  \\\\//");
                G(20,19);puts(" (\xEE)(\xEE)");
                G(20,20);puts("  \xEE  \xEE");
                }
if(joquemeu==2){G(20,17);puts("  ....");
                G(20,18);puts(" ......");
                G(20,19);puts("........");
                G(20,20);puts(" ......"); 
                G(20,21);puts("  ....");    }
if(joquemeu==3){G(20,17);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");
                G(20,18);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");
                G(20,19);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");
                G(20,20);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");
                G(20,21);puts("\xB0\xB0\xB0\xB0\xB0\xB0\xB0");  }
if(joquemeu!=joquepc){
if(joquemeu-1==joquepc)jqponteu++;
if(joquemeu+1==joquepc)jqpontpc++;
if(joquemeu==1 && joquepc==3)jqponteu++;
if(joquepc==1 && joquemeu==3)jqpontpc++;
                       }
delay(1000);
               }//se joquemeu>0 se usuario escolheu algo != sai
G(49,11+joquemy);
printf("%c%c%c%c%c%c%c%c%c%c%c%c%c",201,205,205,205,205,205,205,205,205,205,205,205,187);
G(49,12+joquemy);printf("%c",186);G(61,12+joquemy);printf("%c",186);
G(49,13+joquemy);
printf("%c%c%c%c%c%c%c%c%c%c%c%c%c",200,205,205,205,205,205,205,205,205,205,205,205,188);
G(10,7);printf("PC:%d x VC:%d",jqpontpc,jqponteu);
teclajoque=getch();joquemeu=0;
//gif(teclajoque!=-32 && teclajoque!=13 && teclajoque!=27)continue;
if(teclajoque==-32)teclajoque=getch();
//if(teclajoque!=80 || teclajoque!=72 || teclajoque!=13 || teclajoque!=27)continue;
if(teclajoque==80){joquemy=(joquemy+2)%8;delay(20);continue;}
if(teclajoque==72){joquemy=(joquemy-2)%8;delay(20);continue;}
if(teclajoque==27)break;
if(joquemy==6 && teclajoque==13)break;
if(joquemy==4 && teclajoque==13)joquemeu=3;
if(joquemy==2 && teclajoque==13)joquemeu=2;
if(joquemy==0 && teclajoque==13)joquemeu=1;
                   
                  
                   
         }//fimwhile1
clrscr();
G(2,7); puts("                         .");
G(2,8); puts("                        . .");
G(2,10);puts(".       .  ....  .....  .....");
G(2,11);puts(" .     .  .    . .      .");
G(2,12);puts("  .   .   .    . .      ...");
G(2,13);puts("   . .    .    . .      .  ");
G(2,14);puts("    .      ....  .....  .....");
if(jqponteu==12){
rs=rs+joquemrs;

G(2,16);puts("......  ......  ..      . .      .  .......  .      .   ");
G(2,17);puts(".      .      . . .     . .      . .       . .      .   ");
G(2,18);puts(".      .      . .  .    . .      . .       . .      .   ");
G(2,19);puts(".  ... ........ .   .   . ........ .       . .      .   ");
G(2,20);puts(".    . .      . .    .  . .      . .       . .      .   ");
G(2,21);puts(".    . .      . .     . . .      . .       . .      .   ");
G(2,22);puts("...... .      . .      .. .      .  .......   ......    ");
G(20,23);printf("%d",joquemrs);
delay(4500);
continue;}
else {rs-=joquemrs; 

G(2,16);puts("......  ....... ......    ......    ....... .        .  ");
G(2,17);puts(".     . .       .     .   .      .  .       .        .  ");
G(2,18);puts(".     . .       .     .   .       . .       .        .  ");
G(2,19);puts("......  .....   ......    .       . .....   .        .  ");
G(2,20);puts(".       .       .     .   .       . .       .        .  ");
G(2,21);puts(".       .       .      .  .      .  .        .      .   ");
G(2,22);puts(".       ....... .       . ......    .......   ......    ");
G(20,23);printf("%d",joquemrs);
delay(4500);
continue;}
       //JOQUEMPOFINAL
       
                          }//fimse vai na loja joquempo
antefase=300;
break;

case 200://escola de magia
if(forma!=1)if(forma==2);else forma=1;
gotoxy(31,15);puts(" ______    RECEPCAO");
gotoxy(31,16);  PR("|      |  |   %c   |",2);
gotoxy(31,17);puts("|     c|  =========");
gotoxy(31,18);puts("|      |  =========");
gotoxy(5,19);puts("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH");
if(x>41 && x<49 && tecla==32 && passteste==0){direcional=0;
G(25,8);puts("Charlie Brown:");
G(26,9);puts("Deseja participar do concurso ");
G(27,10);puts("E fazer a prova?((S)im /(N)ao?)");G(27,11);
tecla=getche();if(tecla=='N' || tecla=='n')puts(" Ok...");G(27,11);puts("  ");
G(25,8);PU("                            ");G(26,9);PU("                                   ");G(27,10);PU("                                   ");
if(tecla=='s' || tecla=='S'){tecla='a';
while(saiprova==0){
G(5,12);PU("|AURELIO||HERMIONE|");
G(3,13);PR("     %c   VC  %c",25,25);
G(3,14);PR("         %c            --> FALTAM RESPONDER: %d PERGUNTAS...",25,faltamrespr);
G(7,15);printf(" %c       %c        --> <ESPACO> P/ CHUTAR... <P> P/ PULAR",30,30);
G(7,16);printf(" %c   %c   %c       --> <ENTER> P/ TERMINAR PROVA",2,1,2);
if(((tecla==115 || direcional==75) && hermione==0)|| aurelio==1){
G(7,16);printf(" %c  %c    %c  ",2,1,2);aurelio=1;hermione=0;}
if(((tecla==102 || direcional==77) && aurelio==0)|| hermione==1){
G(7,16);printf(" %c    %c  %c  ",2,1,2);hermione=1;aurelio=0;}
G(7,17);  puts(" =   =   =                                              ");
G(7,18);  puts("! ! ! ! ! !                                              "); 
tecla=getche(); G(1,19);puts(" ");if(tecla==-32){direcional=getche();G(1,20);puts(" ");}
if(tecla=='e' || tecla=='d' || direcional==72 || direcional==80){hermione=aurelio=0;tecla=101;}
if(hermione==1 && aurelio==0 && (tecla=='s' || direcional==75)){
hermione=aurelio=0; tecla=101;}
if(aurelio==1 && hermione==0 && (tecla=='f' || direcional==77)){
hermione=aurelio=0; tecla=101;}
if(faltamrespr==0)saiprova=1;
//saiprova faltamrespr=10;certrespr=0;
// hermione 1,2,3,4,5,7,8,10  aurelio  1,2,3,5,6,7,9,10
switch(faltamrespr){
case 1: if((aurelio==1) && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(hermione==1 && (tecla==3 || tecla==22)){faltamrespr--;}
if(tecla==32){faltamrespr--;}break;
case 2: if((aurelio==1 || hermione ==1) && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(tecla==32){faltamrespr--;certrespr++;}break;
case 3: if((aurelio==1 || hermione ==1) && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(tecla==32){faltamrespr--;}break;
case 4: if(hermione==1 && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(aurelio==1 && (tecla==3 || tecla==22)){faltamrespr--;}
if(tecla==32){faltamrespr--;certrespr++;}break;
case 5: if((aurelio==1 || hermione ==1) && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(tecla==32){faltamrespr--;certrespr++;}break;
case 6: if(aurelio==1 && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(hermione==1 && (tecla==3 || tecla==22)){faltamrespr--;}
if(tecla==32)faltamrespr--;break;
case 7: if((aurelio==1 || hermione ==1) && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(tecla==32)faltamrespr--;break;
case 8: if(hermione==1 && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(aurelio==1 && (tecla==3 || tecla==22)){faltamrespr--;}
if(tecla==32)faltamrespr--;break;
case 9: if((aurelio==1 || hermione ==1) && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(tecla==32){faltamrespr--;certrespr++;}break;
case 10:if((aurelio==1 || hermione ==1) && (tecla==3 || tecla==22)){certrespr++;faltamrespr--;}
if(tecla==32)faltamrespr--;break;}//fimswtich 
if(tecla=='p' || tecla=='P')faltamrespr--;
if(tecla==13)saiprova=1;
}}
if(saiprova==1){clrscr();
G(14,8);puts("    NOTAS:     |RESULTADOS|");
G(14,9);printf("HERMIONE: 8  |REPROVADO |");
G(14,10);   PR("AURELIO : 8  |REPROVADO |");
if(certrespr<10){G(14,11);   PR("VC      : %d  |REPROVADO |",certrespr);}
if(certrespr==10){G(14,11);  PR("VC      : %d  | APROVADO |",certrespr);}
}//ifsaiprova==1
if(certrespr>9 && passteste==0)passteste=1;
saiprova=0;certrespr=0;hermione=0;aurelio=0;faltamrespr=10; //fimenquanto saiprova==0
} // se (s)im desejando participar do concurso...

if(antefase!=200)antefase=200;
break;

case 11: // tela 11 pedreira CEP
gotoxy(1,23);
if(forma==7 && x==22 && tecla=='s'){x++;}
puts("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
G(41,15);puts("    ________  ");
G(41,16);puts("   |        |");
G(41,17);puts("   |      c |");
G(41,18);puts("   |        |");
G(41,19);puts("=============");
if(forma!=1 && forma!=2){
for(int i=6;i<20;i++){
G(20,i);puts("!!!"); }            
                         }
G(20,20);printf(" %c ",2);
G(20,21);printf("/G\\");
G(20,22);printf("/ \\");
if(x==23 && tecla==32 && y==20 &&(forma==1 || forma==2)){//come�a fala gilson honorio
G(3,9);puts("Gilson Honorio: ");
G(3,10);printf("Teste telap%ctico...",160);
G(3,11);printf("pensei em um n%cmero de 0 a 9",163);
G(3,12);puts("concentre-se e me diga ahn ahn...");
G(3,13);tecla=getche();G(3,13);puts(" ");if(randomico!=(tecla-48)){
for (int i=9;i<14;i++){
G(3,i);puts("                                               ");}
G(3,9);puts("ERRADO...");getche();G(3,10);puts(" ");x++;}//fimse errado
if(randomico==(tecla-48)){ //se certo correto
for (int i=9;i<14;i++){
G(3,i);puts("                                               ");}
G(3,9);puts("CORRETO!!!!");G(3,10);getche();G(3,10);puts(" ");
G(23,20-1);printf("\\%c/",1);G(23,21-1);  puts(" #");G(23,22-1);  puts("/ \\");
delay(200);G(23,20-1);printf("      ");G(23,21);  puts("  ");G(23,22);  puts("    ");        
G(23,19-1);printf("%c//",1);G(23,20);  puts("/#");G(23,21);  puts("/ \\");
delay(200);G(23,19-1);printf("    ");G(23,20);  puts("  ");G(23,21);  puts("    ");
G(22,18-1);printf("  / /");G(22,19-1);printf("%c#-�");G(22,20-1);printf(" /");
delay(200);G(22,18-1);printf("     ");G(22,19-1);printf("     ");G(22,20-1);printf("  ");
G(21,17-1);printf(" \\ /");G(21,18-1);printf("%c#",1);G(21,19-1);printf(" / \\");
delay(200);G(21,17-1);printf("     ");G(21,18-1);printf("   ");G(21,19-1);printf("    ");
G(20,17-1);printf("\\ /");G(20,18-1);printf("-#");G(20,19-1);printf(" %c\\",1);
delay(200);G(20,17-1);printf("   ");G(20,18-1);printf("  ");G(20,19-1);printf("   ");
G(19,18-1);printf("\\ /");G(19,19-1);printf("-#");G(19,20-1);printf(" %c\\",1);
delay(200);G(19,18-1);printf("   ");G(19,19-1);printf("  ");G(19,20-1);printf("   ");        
G(18,19-1);printf("\\ /");G(18,20-1);printf("-#%c",1);G(18,21-1);printf("/");
delay(200);G(18,19-1);printf("   ");G(18,20-1);printf("   ");G(18,21-1);printf(" ");
G(17,20-1);printf(" %c",1);G(17,21-1);printf("/#\\");G(17,22-1);printf("/ \\");
delay(200);G(17,20-1);printf("  ");G(17,21-1);printf("   ");G(17,22-1);printf("   \\");

x=17;tecla='a';G(75,2);continue;    
                          }//fimse certo correto          
         }//fim fala gilson honorio
if(conhecimento==12){
gotoxy(12,22);puts("c!!");
if(x<15 && x>11 && y==20 && tecla==32){aprendeu++;continue;}}

if(antefase!=11)antefase=11;
break;

case 12: // tela 12
if(antefase==9){tecla='a';y=19;}
if(antefase==8){tecla='a';}
G(2,17);   PR(" =, ,=====",190);//190
G(2,18); puts(" | _____ |");
G(2,19); puts(" ||=====||");
G(2,20); puts(" ||     ||  ");
G(2,21); puts(" ||     || ");
G(2,22); puts("!=========!");
gotoxy(2,23);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
G(17,12);puts("          /\\ ");
G(17,13);puts("         /  \\");
G(17,14);puts("        /.-. \\");
G(17,15);puts("       /      \\");
G(17,16);puts("      / ---    \\");
G(17,17);puts("     /          \\");
G(17,18);puts("    /    ..-     \\ ");
G(17,19);puts("   /   -       _  \\");
G(17,20);puts("  /    .      |=|  \\");
G(17,21);puts(" /       .-.  ###   \\");
G(17,22);puts("/                    \\");
G(50,9); puts(" ____");
G(50,10);puts("|    |");
G(50,11);puts("|   c|");
G(50,12);puts("|    |"); 
G(43,13);puts("======================");
G(40,pgpiramide);puts("|=|");
if(x<8 && x>4 && y==19 && tecla==32 && passaporte>0){
tecla='a';tela=9;fase=9;y=10;delay(200);continue;  }
if(pgpiramide==21 && x>37 && x<43 && tecla==32 && y==20){G(51,8);puts("CODIGO MORSE");
G(38,9); puts("A= .-    H= ....            T= -");
G(38,10);puts("B= -...  I= ..              U= ..-");                  
G(38,11);puts("C= -.-.  J= .--- O= ---     V= ...-");
G(38,12);puts("D= -..   K= -.-  P= .--.    W= .--");
G(38,13);puts("E= .     L= .-.. Q= --.-    X= -..-");
G(38,14);puts("F= ..-.  M= --   R= .-.     Y= -.--");
G(38,15);puts("G= --.   N= -.   S= ...     z= --..");}
if(x>29 && x<32 && y==20 && tecla==32 && openpiramide!=1){
G(45,16);puts("CODIGO PIRAMIDAICO:");
G(45,17);scanf("%s",&resp);
if(strlen(resp)<7)
if(resp[0]=='r'&&resp[1]=='o'&&resp[2]=='u'&&resp[3]=='t'&&resp[4]=='e'&&resp[5]=='r')
{
openpiramide=1; 
for(int i=0;i<5;i++){
G(23,18);puts(" ______");
G(23,19);puts("|######|");
G(23,20);puts("|######|");
G(23,21);puts("|######|");
G(23,22);puts("|######|");delay(100);
G(23,18);puts("        ");
G(23,19);puts("         ");
G(23,20);puts("         ");
G(23,21);puts("         ");
G(23,22);puts("         ");delay(100);}
tecla='a';
continue;

                                                                                                                                                                            
}
                          }
if(openpiramide==1){
G(17,17);puts("     /          \\");
G(17,18);puts("    /  ______    \\ ");
G(17,19);puts("   /  |######| _  \\");
G(17,20);puts("  /   |######||=|  \\");
G(17,21);puts(" /    |######|###   \\");
G(17,22);puts("/     |######|       \\");
if(x>23 && x<28&& y==20 && tecla==32){tela=8;fase=8;continue;}
                     } 
if(x>29 && x<32 && y==20 && tecla==32 && openpiramide==1){
quantia=0;
G(45,16);printf("sua: RS %d",sua);
G(45,17); puts("1. extrato");
G(45,18);puts("2. deposito");
tecla=getch();
if(tecla=='1'){
G(55,19);puts("Quantia: ");               
G(55,20);scanf("%d",&quantia);
if(sua>=quantia){sua-=quantia;rs+=quantia;}
               }
if(tecla=='2'){
G(55,19);puts("Quantia: ");               
G(55,20);scanf("%d",&quantia);
if(rs>=quantia){sua+=quantia;rs-=quantia;}               
               }

        }
//if(x>4 && x<8 && y==19 && tecla==32){tela=9;fase=9;tecla='a';continue;}
if(aprendeu==14){delay(1500);
clrscr();G(18,19);printf("%c:",1);delay(1500);                 
G(20,20);puts("e");T;G(21,20);puts("s");T;
G(22,20);puts("t");T;G(23,20);puts("a");T;
G(24,20);puts(" eh");T;G(27,20);puts(".");T;
G(29,20);puts(".");T;G(30,20);puts(".");T;
G(20,21);puts("A ");T;G(22,21);puts("P");T;
G(23,21);puts("i");T;G(24,21);puts("r");T;                 
G(25,21);puts("a");T;G(26,21);puts("m");T;
G(27,21);puts("i");T;G(28,21);puts("d");T;
G(29,21);puts("e ");T;G(20,22);puts("L");T;
G(21,22);puts("e");T;G(22,22);puts("n");T;
G(23,22);puts("d");T;G(24,22);puts("a");T;
G(25,22);puts("r");T;G(26,22);puts("i");T;
G(27,22);puts("a");T;G(28,22);puts("!");T; W;
getch();aprendeu++;continue;
                 }

if(antefase!=12)antefase=12;
break;

case 13: //tela 13
if(antefase!=13)antefase=13;
break;

case 14: //tela 14
if(antefase!=14)antefase=14;
break;

//CASAS  casas CASAS 
/////////////////////////////////////////
case 110: // hotel hub
if(forma!=1)if(forma==2);else forma=1;
if(antefase==6){x=8;y=20;antefase=110;}
G(46,20);puts("| A1  |");G(46,21);puts("|    c|");G(46,22);puts("|     |");
G(46,16);puts("| B1  |");G(46,17);puts("|    c|");G(46,18);puts("|     |");
G(33,16);puts("| B2  |");G(33,17);puts("|    c|");G(33,18);puts("|     |");
G(13,16);puts("| B3  |");G(13,17);puts("|    c|");G(13,18);puts("|     |");
G(56,12);puts("| C1  |");G(56,13);puts("|    c|");G(56,14);puts("|     |");
G(41,12);puts("| C2  |");G(41,13);puts("|    c|");G(41,14);puts("|     |");
G(8,8);puts("| D1 |");G(8,9);puts("|   c|");G(8,10);puts("|    |");   
G(33,20);puts("| TV  |");G(33,21);puts("|     |");G(33,22);puts("|     |");
gotoxy(2,23);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,19);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,15);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,11);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
gotoxy(2,7);puts("WWWWWWWWWWWWWWWWWWWWWWWWWWW");
G(28,8);puts("W");G(28,9);puts("W");G(28,10);puts("W");
G(20,22);puts("|      |");G(20,21);puts("|      |");G(20,20);puts("|      |");
G(20,18);puts("|      |");G(20,17);puts("|      |");G(20,16);puts("|      |");
G(20,14);puts("|      |");G(20,13);puts("|      |");G(20,12);puts("|      |");
G(20,10);puts("|      |");G(20,9);puts("|      |");G(20,8);puts("|      |");
G(6,20); puts("|       |");G(6,21);puts("|      c|"); G(6,22);puts("|       |"); 
if(x>20 && x<25 && tecla==32){
if(andars>2)y=y+4;else y=y-4;
andars=(andars+1)%6;}
break; // break; hotel hub (dentro)

case 111: // sala de video
gotoxy(5,23);puts("VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
gotoxy(6,19);puts(".   .");
gotoxy(6,20);puts(" \\_/ ");
gotoxy(6,21);puts(" |_|  =");
gotoxy(6,22);puts("||||||||");
G(33,20);puts("|SAIDA|");G(33,21);puts("|     |");G(33,22);puts("|     |");
if(x<10 && tecla==32){//se ve tv
comentv=conhecimento;
if(conhecimento<5)comentv=1;
if(conhecimento==0)comentv=0;
if(randomico==5)comentv=0;
switch(conhecimento){
     case 0: clrscr();
     G(10,9);puts("PALMEIRAS 7 x 0 CORINTHIANS ");delay(2000);W;
     tecla='a';continue;
     break;     
     case 1:clrscr();
     G(10,9); puts("Diretamente do JORNAL NACIONAL");
     G(10,10);puts("O professor Cabrini ");delay(2000);
     G(10,11);puts("Esta desaparecido, e...");delay(2000);
     G(10,12);puts("Seu filho Ronney esta muito preocupado...");delay(2000);
     G(10,13);puts("Ronney: Sniff...");delay(2000);
     G(10,14);puts("Sniff...");delay(2000);tecla='a';continue;
     break;  
     case 99:     clrscr();
     G(10,10);puts("Um adolescente de 18 anos...");delay(1000);
     G(10,11);puts("tornou-se o segundo homem mais rico do mundo");delay(2000);
     G(10,12);  PR("Seu nome %c William Ribeiro",130 );delay(1000);
     G(10,13);puts("De alguma maneira Este jovem demonstrou sua inteligencia");delay(2000); 
     G(10,14);puts("Desenvolvendo uma formula que cria numeros primos...");delay(2000);
     G(10,15);puts("Esta sendo procurado pela NSA e Agencias secretas");delay(2000);
     G(10,16);puts("Enquanto faz um misterioso acordo com a NASA");delay(2000);
     G(10,17);puts("Ninguem sabe onde ele esta!!!");delay(2000);
     G(10,18);puts("Voce sabe?????"); delay(3500);
     clrscr();
     G(10,10);puts("   /////////////");
     G(10,11);puts(" _| ___    ___ |_");
     G(10,12);puts("(9|( o )||( o )|P)");
     G(10,13);puts(" (|     ==     |) ");
     G(10,14);  PR("  |    %c%c%c%c    |",200,205,205,188);delay(5000);
G(10,15);  PR(" Se o encontrar, estamos dando uma recompensa de");
G(10,16);puts("R$ 1000000,00  P/ quem trazer aqui no estudio 1 autografo dele");
delay(5000);delay(4000);tecla='a';continue;
     default:
             clrscr();
     G(10,10);puts("O Lord V...");delay(1000);
     G(10,11);puts("Bem, AQUELE-QUE-NAO-DEVE-SER-MENCIONADO");delay(2000);
     G(10,12);puts("Esta aterrorizando a todos....");delay(1000);
     G(10,13);puts("Vejam este video amador....");delay(2000); 
             for (int i2=0;i2<10;i2++){clrscr();
             G(20-i2,15);printf("    %c",30);
             G(20-i2,16);printf("    %c",153);
             G(20-i2,17);printf("__//V__,,",93,93);
    G(20-i2,18);printf("%c%c%c%c%c%c%c%c%c",238,238,238,238,238,238,238,94,94);
             for (int i=10;i<14;i++){
G(10,i);puts("                                                         ");}
if(i2==0){G(10,10);puts("Eu quero a pedra filosofal...");delay(1000);
G(10,11);puts("Tragam-me, ou eu continuarei a destruir!!!");delay(2000);
G(10,12);puts("Td e todos nao estam seguros enquanto eu sobreviver");delay(1000);
G(10,13);puts("Esta eh a nova profecia!!!!");delay(2000); 
G(10,14);puts("HAHAHAHAHAHAHA HAHAHAHAHAHA");getche();}break;}
tecla='a';continue;
break;

             
                          }
}//fimse ve tv
break;

case 101://HOUSE RONNEY
if(forma!=1)if(forma==2);else forma=1;
if(aprendeu==0)aprendeu=1;
gotoxy(46,15);puts(" ______ ");
gotoxy(46,16);puts("|      |");
gotoxy(46,17);puts("|     c|");
gotoxy(46,18);puts("|      |");
gotoxy(5,19);puts("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH");
gotoxy(6,14);  puts("       __    _ ");
gotoxy(6,15);  puts("       |_\\  |-|");
gotoxy(6,16);printf("  %c    _X___|=|",1);
gotoxy(6,17);  puts(" |R|=_|___||XX|");
gotoxy(6,18);  puts(" | |  | |  |  |");
if(conhecimento>5){G(3,16);printf(" %c",1);
G(2,17);  puts("/|C|\\");
G(3,18);  puts(" -\\\\");}
gotoxy(56,16); puts("  |HH|");
gotoxy(56,17);puts(" /####\\");
if(tecla==32 && x<25){
if(conhecimento<6 && forma==1){
gotoxy(1,7);puts("RONNEY: \n");
puts("PEDI UM LIVRO AO MEU PAI... ELE FOI COMPRAR FAZ\n");
puts("10 HORAS E ATE AGORA NAO VOLTOU\n");
puts("ESTOU MUITO PREOCUPADO...KD O CABRINI??????");}//fechacon<6
if(conhecimento==6){
gotoxy(1,7);puts("RONNEY E CABRINI:\n");
puts("Estamos agradecidos por vc ter me salvado!!!\n");
puts("Como prova de nossa gratid�o...\n");
puts("Lhe daremos este presente\n");livro=1;aprendeu++;continue;
}
if(conhecimento>7){gotoxy(1,7);puts("...");}
}//caso fale com ronney || Cabrini

// MEXENDO NO PC

if(x==53 && tecla==32){
gotoxy(1,7); mostra=0;
puts("COMPUTADOR CONECTADO AO DO BANCO\n");
printf("1.Demilton R$: %d\t2.Dimas R$:%d\n",demilton,dimas);
printf("3.Cabrini R$:%d\t4.SUA R$:%d\n5.Harry Potter R$: %d",cabrini,sua,hp);
delay(200);gotoxy(46,11);
puts("USUARIO");gotoxy(45,12);tecla=getche();
/*scanf("%d",&usuario);*/ usuario=tecla-48;
if((usuario<6 && usuario>0) ){
if(usuario!=4){
gotoxy(55,11);puts("senha : ");
gotoxy(55,12);scanf("%s",&pc);}}
else if(usuario !=4){gotoxy(55,11);puts("NAO EXISTE USUARIO SOLICITADO!");}
certo=certsenha(pc,usuario,fase); //printf("certo = %d",certo);getche();
switch(usuario){
case 1:{if(certo==1){if(demilton>0){sua=sua+demilton;demilton=0;}
gotoxy(31,13);printf("VC PEGOU TODO DINHEIRO DA CONTA DEMILTON");} //fim usuario1
}break;
case 2:{if(certo==1){if(dimas>0){sua=sua+dimas;dimas=0;}
gotoxy(31,13);puts("VC PEGOU TODO O DINHEITO DA CONTA BIGODIMAS");}
//if(certo==0){gotoxy(31,13);printf("SENHA INCORRETA",certo); certo=2;} //fim usuario1
}break;
case 3:{if(certo==1){if(cabrini>0){sua=sua+cabrini;cabrini=0;}
gotoxy(31,13);puts("VC PEGOU TODO O DINHEIRO DA CONTA CABRINI");}}break;
case 4:gotoxy(40,7);puts("Deseja depositar/tirar(d/t)?");
gotoxy(70,7);pegasua=getche();
if(pegasua=='t'){
gotoxy(45,9);puts("digite a quantia : ");gotoxy(45,10);scanf("%d",&quantia);
if(quantia <= sua){rs=rs+quantia;sua=sua-quantia;}}//fim se pegasua=t
if(pegasua=='d'){
gotoxy(45,9);puts("digite a quantia : ");gotoxy(45,10);scanf("%d",&quantia);
if(quantia <= rs){sua=quantia+sua;rs=rs-quantia;}}//fim se pegasua=d
gotoxy(31,13);puts("                                         "); break;
case 5:{if(certo==1){if(hp>0){sua=sua+hp;hp=0;}
gotoxy(31,13);puts("VC PEGOU TODO O DINHEIRO DA CONTA HARRY POTTER");}break;}break;
 break;    

           
}//fim switch usuario
if(certo==0 && usuario <6 && usuario >0 && usuario !=4)
{gotoxy(31,13);printf("SENHA INCORRETA",certo); certo=2;}
}//fim ve PC
}// fim se mexe no pc (espaco no local do PC)
}



//fim teste desenho de tela
//fim teste desenho de tela
//fim teste desenho de tela
//fim teste desenho de tela
//fim teste desenho de tela
//fim teste desenho de tela
//fim teste desenho de tela
//fim teste desenho de tela
//fim teste desenho de tela


//imprime o boneco
       randomico=rand()%10;
       int rosto=1;
       for (int i=9;i>0;i--){
                       bonec[i]=muda(forma,i,0);
                       }bonec[0]=32;
       gotoxy(x+1,y); if(forma<3) printf("%c",bonec[1]);
       gotoxy(x,y+1);if(forma<6) printf("%c%c%c",bonec[3],bonec[4],bonec[5]);
       gotoxy(x,y+2);if(forma<9 && forma !=7) printf("%c%c%c",bonec[6],bonec[7],bonec[8]);
       if(forma==7){x=x+1;y=y+2;gotoxy(x,y);
                    printf("%c",bonec[7]);}
       
       if(maxpower>1){
       gotoxy(60,1);printf("x=%d,y=%d,fase=%d",x,y,fase);
       // G(70,2);printf("%d",pgpiramide);
       G(70,2);printf("%d",forma);
       gotoxy(60,3);printf("cont=%d liv=%d r=%d",contlivro,livro,randomico);}
             if(subir==0)b=cai(x,y,fase,forma); 
             if(y==pgpiramide-3 && fase==12 && x>37 && x<43){b=1;}
             if(y==9 && x-pgindio>-3 && x-pgindio<3){b=1;}
             if(b==0){
             y++;delay(100);continue;}
                /*while(b==0){
                y++;    gotoxy(x,y-1);printf("  ");
         
       gotoxy(x,y);  if(forma<3) printf("%c%c%c\n",bonec[0],bonec[1],bonec[2]);
       gotoxy(x,y+1);if(forma<6) printf("%c%c%c\n",bonec[3],bonec[4],bonec[5]);
       gotoxy(x,y+2);if(forma<9 && forma !=7)printf("%c%c%c\n",bonec[6],bonec[7],bonec[8]); 
       gotoxy(x+1,y+2);if(forma==7)printf("%c",bonec[7]);
       delay(100);
       b=cai(x,y,fase,forma);
                }*/
       if(subir==0) 
       b=cai(x,y,fase,forma);
       gotoxy(75,1);

//le a tecla pressionada teclando movimentacao 
   if(x>37 && x<43 && fase==12 && y==pgpiramide-3){ b=1;}
   if(y==9 && x-pgindio>-3 && x-pgindio<3){b=1;}
       if(x>22 && x<26 && subir==1 && fase ==1 && y==9 && aprendeu>30){
       if(y==9 && x==23){x--;delay(100);}
       if(x<23){subir=0;continue;}
       if(x==23){subir=0;continue;}
       x--;delay(100);subir=1;continue;}
       if(subir==1){delay(100); y--;continue;}
       if(jogoteste==1){ //zuando o jogo
       if(tecla==68){ 
system("cls");system("dir | more"); tecla='a'; 
getch();continue;
                    }
       if(tecla==87){
system("cls"); for(int i=0; i<250;i++)system("echo. william , vc eh foda!");
tecla='a'; continue;
                     }
       if(tecla==84 || tecla==44){
system("cls");system("date/t");system("time/t"); getche();
tecla='a';continue;
                                 }
       } // zuando o jogo
       //le a tecla teclando direcionando o boneco
       if(tecla!=1)tecla = getch();
       if(tecla==13 && goku==2)tecla=1;
       direcional=(int)tecla;
       if(direcional==-32){ direcional=getch();
       if(direcional==75)tecla='s';
       if(direcional==77)tecla='f';
       if(direcional==80)tecla='d';
       if(direcional==72)tecla='e';
       if(direcional==73 && fase==12 && pgpiramide>12){
       if(x>37 && x<43 && y==pgpiramide-3)y-=1;
       pgpiramide--;     }
       if(direcional==81 && fase==12 && pgpiramide<21){
       //if(x==40 && y==pgpiramide-3)y+=2;
       pgpiramide++;}
       if(maxpower>0){
       if(direcional==133)system("color 07");
       if(direcional==134)system("color 02");
       if(direcional==82) system("color 0d");}}//fimifmaxpower fimdirecional
       if(direcional==0){direcional=getch();
       if(direcional==61)system("color 04");
       if(direcional==62)system("color 08");
       if(direcional==64)system("color 09");
       if(direcional==65)system("color 0a");
       if(direcional==66)system("color 0b");
       if(direcional==67)system("color 0c");
       if(direcional==68)system("color 0e"); }
       if(tecla==1){  clrscr();
       andars=0;
       gotoxy(1,2);puts("Qual a tela:\n");
       puts("a. ksa do Osvaldir");
       puts("b. casa do ronney");
       puts("c. fora do shopping");
       puts("d. guardinha");
       puts("e. posto e hotel");
       puts("f. Hogwarts");
       puts("g. labirinto");
       if(aprendeu>13)puts("h. las vegas");                
       if(aprendeu>40)puts("i. Cidade das piramides");
       //       puts("h. moco dos baus");
       gotoxy(x+1,y+1);tecla=getche();
       if(tecla>64)william=tecla-64;
       if(tecla>96)william=tecla-96;
       if(tecla>48 && tecla<58)william=tecla-48;
       switch(william){
       case 1: fase=3;x=28;y=11;break;
       case 2: fase=1;x=34;y=16;break;
       case 3: fase=2;x=25;y=16;break;
       case 4: fase=5;x=13;y=20;break;
       case 5: fase=6;x=58;y=20;break;
       case 6: fase=7;x=22;y=20;break;
       case 7: fase=8;x=22;y=20;break;
       case 8: if(aprendeu<14)break;
               fase=9;x=36;y=20;break;
       case 9: fase=12; x=6;y=19; break;        
  //     case 8: fase=9;x=22;y=20;break;
       }//fimswitch
       tela=fase;    continue;}
       if(tecla<65 && maxpower>0){
       switch(tecla){
       case 2:speed=0;break;
       //case 3:speed=1;break;
       case 4:speed=2;break;
       case 5:speed=3;break;
       case 6:speed=4;break;
       case 16: speed=speed;break;
       default: break;
       }}
              
       if(tecla==32 && fase==1 && x==25 && y==16 && aprendeu>30){
       subir=1;continue;
       } 
       if(maxpower>0)if(tecla=='q')mostra=(mostra+1)%2;
       c=topo(x,y,fase,forma); muro=parede(x,y,fase,forma);
       if(forma==1 || (forma==2 && tecla==32)){
       switch(tecla){
                 case 's':if(muro!=0){ x--;
                                  for (int i=0; i<3;i++){                                                
                                  gotoxy(x, y+i); printf("    ");
                                  }
                                  gotoxy(x, y);   printf("_%c \n",rosto);
                                  gotoxy(x, y+1); printf(" %c\\\n",barrig);
                                  gotoxy(x, y+2); printf("< \\" );break;}break;
                 case 'f':if(muro!=1){
                                  x++;
                                  for (int i=0; i<3;i++){
                                      
                                  gotoxy(x-1, y+i); printf("    ");}
                                  gotoxy(x, y);   printf(" %c_\n",rosto);
                                  gotoxy(x, y+1); printf("/%c\n",barrig);
                                  gotoxy(x, y+2); printf("/ >");break;}break;
                 case 'e':        
                      if(c==1){for(int i=0;i<3+jump;i++){
                                  for (int i=0; i<3;i++){
                                  gotoxy(x, y+i);   printf("   ");}
                                  y--;
                                  gotoxy(x, y);   printf("\\%c/\n",rosto);
                                  gotoxy(x, y+1); printf("_%c_\n",barrig);
                                  gotoxy(x, y+2); printf("     ");delay(2*tempo);}
                                   }
                           break;
                 case 'w':        if(diagonal==0)break;
                                  muro=paredep(x,y,fase,forma);
                                  if(c==1 && muro!=0){
                                  for(int i=0;i<4;i++){
                                   for (int i=0; i<3;i++){
                                  gotoxy(x, y+i);   printf("   ");}
                                  y--;x--;
                                  
                                  gotoxy(x, y);   printf("\\%c\n",rosto);
                                  gotoxy(x, y+1); printf(" %c\\ \n",barrig);
                                  gotoxy(x, y+2); printf(" \\\\");delay(2*tempo);}
                                  }   break;        
                     case 'r':    if(diagonal==0)break;
                                  muro=paredep(x,y,fase,forma);
                                  if(c==1 && muro!=1) {
//                                  if(aprendeu==0)aprendeu=1;
                                  for(int i=0;i<4;i++){
                                   for (int i=0; i<3;i++){
                                  gotoxy(x, y+i);   printf("   ");}
                                  y--;x++;
                                  gotoxy(x, y);   printf(" %c/\n",rosto);
                                  gotoxy(x, y+1); printf("/%c \n",barrig);
                                  gotoxy(x, y+2); printf("//");delay(2*tempo);}
                                }
                           break;                           
                 case'd':{        gotoxy(x, y);   printf("   ");
                                  gotoxy(x, y+1); printf("\\%c/",rosto);
                                  gotoxy(x,y+2);  printf("_%c_",barrig);
                                  delay(700);}break;
                 case 32: {         tela=mudafase(x,y,fase);}  break;
                                 
                 } }
                 
               // MOVIMENTO COM OUTRAS FORMAS
               else{
                    if(forma==7){
                    switch(tecla){ 
                    case 's': if(muro!=0)x=x-2;
                              y=y-2;break;
                    case 'f': if(muro!=1);   y=y-2;
                              if(muro==1)x--;
                              break;
                    case 'e': if(c==1){y=y-2;x--;}
                              if(c==0)if(x<10)x++;
                              break;
                    /*case 'd': if(b==1 && c==1)y++;
                              if(c==0)if(x<10)x=x+3;else y=y-3;*/
                    default: y=y-2;x--;break;
                    for (int i=9;i>0;i--){
                       bonec[i]=muda(forma,i,0);
                       }bonec[0]=32;
       gotoxy(x,y);  if(forma<3) printf("%c%c%c",bonec[0],bonec[1],bonec[2]);
       gotoxy(x,y+1);if(forma<6) printf("%c%c%c",bonec[3],bonec[4],bonec[5]);
       gotoxy(x,y+2);if(forma<9) printf("%c%c%c",bonec[6],bonec[7],bonec[8]);
       //gotoxy(x-1,y+2);if(forma==7)printf("%c",bonec[7]);            
                    
                    }//fimswitch
                    }//fim se forma=7
                    if(forma==6){
                    c=topo(x,y,fase,forma);
                    if(subir==0)b=cai(x,y,fase,forma);
                    //gotoxy(x-2,y-1);puts("   ");
                    //if(tecla=='e'){if(c==1)y=y-2;}
                    //if(tecla=='d'){if(b==0)y++;}
                    switch(tecla){
                     case 'e': if(c==1){y--;}
                              //if(c==0) y--;
                              break;
                   // case 'd': if(b==0)y++;break;
                              //if(c==0)if(x<10)x=x+3;else y=y-3;
                    }
                    }
                    
                    if(forma!=7 && forma !=6){
                    muro=parede(x,y,fase,forma);
                    switch(tecla){ 
                    case 's': if(muro!=0)x--; 
                              break;
                    case 'f': if(muro!=1)x++; 
                              break;
                    default: break;
                    for (int i=9;i>0;i--){
                       bonec[i]=muda(forma,i,0);
                       }bonec[0]=32;
       gotoxy(x,y);  if(forma<3) printf("%c%c%c",bonec[0],bonec[1],bonec[2]);
       gotoxy(x,y+1);puts("   ");if(forma<6)printf("%c%c%c",bonec[3],bonec[4],bonec[5]);
       gotoxy(x,y+2);puts("   ");if(forma<9) {
       printf("%c%c%c",bonec[6],bonec[7],bonec[8]);}
                    
                    } //fim else
                    }   }    
               // FIM MOVIMENTO COM FORMAS > 0
                delay(tempo);
                while(b==0){y++;
                
             for (int i=0;i<9;i++){
                       bonec[i]=muda(forma,i,0);
                       }
       gotoxy(x,y); if(forma<3)printf("%c%c%c",bonec[0],bonec[1],bonec[2]);
       gotoxy(x,y+1);if(forma<6)printf("%c%c%c",bonec[3],bonec[4],bonec[5]);
       gotoxy(x,y+2);if(forma<9) printf("%c%c%c",bonec[6],bonec[7],bonec[8]);
       //gotoxy(x-1,y+2);if(forma==7)printf("%c",bonec[7]);
       delay(tempo);
       if(subir==0)b=cai(x,y,fase,forma);
             
       }
      // clrscr();
                
                
       }//fim while(tecla != 27)
       clrscr();
       password=qualpassword(conhecimento);
       for (int i=18;i<25;i++){
       gotoxy(i,15);
       printf(" VOLTE SEMPRE, PASSWORD: %d ",password);delay(100); }
       gotoxy(18,11);
       puts("Doun Doun..."); 
       puts("criticas e sujestoes: dev-br88@hotmail.com\n \t\t\tWilliam");
if(vida==0){
gotoxy(2,2);puts(" ___    __              __ ");         
gotoxy(2,3);puts("|  _   |__|   /\\  /\\   |_   ");
gotoxy(2,4);puts("|___|  |  |  /  \\/  \\  |__ ");delay(100);
gotoxy(2,5);puts(" __         __  __");
gotoxy(2,6);puts("|  |  \\  / |_  |__)");
gotoxy(2,7);puts("|__|   \\/  |__ |  \\");
getche();
            }
       getche();
}
/* pedir ajuda F1
if(direcional==0){
       direcional=getch();
       if(direcional==59){
       clrscr();
       gotoxy(10,10);puts("AJUDA");getche();}
       }
 RENOMEAR F2
if(direcional==0){
       direcional=getch();
       if(direcional==60){
       clrscr();
       gotoxy(10,10);puts("RENOMEAR");getche();}
       }
 SAIR
if(direcional==0){
       direcional=getch();
       if(direcional==107){
       clrscr();
       gotoxy(10,10);puts("SAIR");getche();}
       }
ATUALIZAR
if(direcional==0){
       direcional=getch();
       if(direcional==63){
       clrscr();
       gotoxy(10,10);puts("ATUALIZAR");getche();}
       }
HOME
if(direciona==-32){
        direcional=getch();
       if(direcional==71){
       clrscr();
       gotoxy(10,10);puts("HOME");getche();}
       }
END
 if(direciona==-32){
        direcional=getch();
       if(direcional==79){
       clrscr();
       gotoxy(10,10);puts("HOME");getche();}
       }
DELETE
if(direciona==-32){
        direcional=getch();
       if(direcional==83){
       clrscr();
       gotoxy(10,10);puts("DELETE");getche();}
       }
INSERT
if(direciona==-32){
        direcional=getch();
       if(direcional==82){
       clrscr();
       gotoxy(10,10);puts("INSERT");getche();}
       }
PAGE UP
if(direciona==-32){
        direcional=getch();
       if(direcional==73){
       clrscr();
       gotoxy(10,10);puts("PGUP");getche();}
       }
  PAGE DOWN
if(direciona==-32){
        direcional=getch();
       if(direcional==81){
       clrscr();
       gotoxy(10,10);puts("PGDOWN");getche();}
       }  
  FECHA PARENTESES
if(tecla==41){
       clrscr();
       gotoxy(10,10);puts("fecha parenteses");getche();}
  IGUAL
  MAIOR
  MENOS
  +
  -
  
  
       */

